
/* ═══════════════════════════════════════════════════════════
   ĀROGYA · script.js  — Production v2
   ═══════════════════════════════════════════════════════════

   FIX LOG
   -------
   1. SOUND      — Web Audio API synthesiser + fallback audio elements
                   + user-interaction unlock gate
   2. STREAK     — Starts at 0 for new users, increments on daily
                   completion, resets if a day is missed
   3. MULTI-SELECT — Intentions and traits are multi-select;
                   dosha is multi-select (combos); tradition is
                   single-select (strict)
   4. DOSHA COMBO — Scores produce Vata/Pitta/Kapha/VP/PK/VK/VPK
                   combinations; dinacharya is generated for each
   5. ADAPTIVE DINA — Every timeline card is generated from the
                   user's exact dosha combo + current mood
   6. TRADITION FILTER — Journal prompts, programme content, and
                   home verse are strictly filtered by chosen
                   tradition; nothing from other traditions leaks
   7. ACCURACY   — All content keyed to dosha + mood + tradition;
                   zero placeholder text
   8. UX         — Selection counts, checked badges, combo labels
   ═══════════════════════════════════════════════════════════ */

'use strict';

/* ═══════════════════════════════════════════════════════════
   SECTION 1 · STATE
   Single source of truth for everything the app knows about
   the user. Persisted to / loaded from localStorage.
   ═══════════════════════════════════════════════════════════ */
var STATE = {
  // onboarding
  userName:      '',
  intentions:    [],   // multi-select keys
  traits:        [],   // multi-select keys
  doshaScores:   { vata:0, pitta:0, kapha:0 },
  doshaCombo:    [],   // e.g. ['vata','pitta']
  tradition:     '',   // 'hindu' | 'thay' | 'buddhist' | 'universal'
  onboardDone:   false,

  // streak
  streak:        0,
  lastActiveDate: '',  // 'YYYY-MM-DD'
  bellsHeard:    0,
  sessionsTotal: 0,
  todayDone:     0,    // activities completed today
  progDay:       0,    // 21-day programme current day

  // sound
  soundUnlocked: false,
  sessionSound:  'om'  // 'bell' | 'om' | 'both' | 'silent'
};

/* ═══════════════════════════════════════════════════════════
   SECTION 2 · PERSISTENCE
   ═══════════════════════════════════════════════════════════ */
function saveState() {
  try { localStorage.setItem('arogya_state', JSON.stringify(STATE)); } catch(e) {}
}

function loadState() {
  try {
    var raw = localStorage.getItem('arogya_state');
    if (!raw) return false;
    var saved = JSON.parse(raw);
    Object.assign(STATE, saved);
    return true;
  } catch(e) { return false; }
}

/* ═══════════════════════════════════════════════════════════
   SECTION 3 · SOUND ENGINE
   Web Audio API for synthesised Om / bell tones.
   Falls back to <audio> elements.
   Gate: sounds only play after user has interacted once.
   ═══════════════════════════════════════════════════════════ */
var AudioCtx = null;

function getAudioContext() {
  if (!AudioCtx) {
    try {
      AudioCtx = new (window.AudioContext || window.webkitAudioContext)();
    } catch(e) { AudioCtx = null; }
  }
  return AudioCtx;
}

/* Synthesise an Om-like sustained drone */
function synthesiseOm(duration) {
  var ctx = getAudioContext();
  if (!ctx) return;

  try {
    // Resume if suspended (autoplay restriction)
    if (ctx.state === 'suspended') ctx.resume();

    var now = ctx.currentTime;
    var dur = duration || 3;

    // Fundamental + harmonics that approximate Om
    var freqs = [110, 165, 220, 275, 330];
    freqs.forEach(function(freq, i) {
      var osc  = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = i === 0 ? 'sawtooth' : 'sine';
      osc.frequency.setValueAtTime(freq, now);
      // Fade in
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.08 / (i + 1), now + 0.4);
      // Sustain then fade out
      gain.gain.setValueAtTime(0.08 / (i + 1), now + dur - 0.6);
      gain.gain.linearRampToValueAtTime(0, now + dur);
      osc.start(now);
      osc.stop(now + dur);
    });
  } catch(e) { playFallbackAudio('om'); }
}

/* Synthesise a Tibetan bowl bell */
function synthesiseBell() {
  var ctx = getAudioContext();
  if (!ctx) return;

  try {
    if (ctx.state === 'suspended') ctx.resume();

    var now  = ctx.currentTime;
    var dur  = 4;
    // Bowl frequencies (harmonic partials)
    var partials = [432, 864, 1296, 1728];
    partials.forEach(function(freq, i) {
      var osc  = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);
      var peak = 0.18 / (i + 1);
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(peak, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
      osc.start(now);
      osc.stop(now + dur);
    });
  } catch(e) { playFallbackAudio('bell'); }
}

/* Fallback: try the <audio> elements */
function playFallbackAudio(type) {
  var el = document.getElementById('audio-' + type);
  if (el) {
    el.currentTime = 0;
    el.play().catch(function() {
      // Still blocked — user has not interacted enough
      showSoundNotice();
    });
  }
}

function showSoundNotice() {
  var notice = document.getElementById('sound-unlock-notice');
  if (notice) notice.classList.remove('hidden');
}

function hideSoundNotice() {
  var notice = document.getElementById('sound-unlock-notice');
  if (notice) notice.classList.add('hidden');
}

/* Public: play the bell based on current setting */
function playBell(type) {
  if (!STATE.soundUnlocked) return;
  var t = type || STATE.sessionSound;
  if (t === 'silent') return;
  if (t === 'bell' || t === 'both') synthesiseBell();
  if (t === 'om'   || t === 'both') {
    var delay = (t === 'both') ? 4200 : 0;
    setTimeout(function() { synthesiseOm(3); }, delay);
  }
}

/* Called on the bell card tap — first tap unlocks, subsequent taps ring */
function handleBellTap() {
  // First interaction — unlock audio context
  if (!STATE.soundUnlocked) {
    var ctx = getAudioContext();
    if (ctx && ctx.state === 'suspended') ctx.resume();
    STATE.soundUnlocked = true;
    saveState();
    hideSoundNotice();
    updateBellButton('▶');
    // Play immediately on first tap
    synthesiseOm(3);
    STATE.bellsHeard++;
    updateStats();
    saveState();
    return;
  }

  // Subsequent taps just ring
  synthesiseOm(3);
  STATE.bellsHeard++;
  updateStats();
  saveState();
}

function updateBellButton(icon) {
  var btn = document.getElementById('omPlayBtn');
  if (btn) btn.textContent = icon;
}

/* Hourly bell — starts once unlocked */
function scheduleHourlyBell() {
  var now = new Date();
  var msUntilNextHour = (60 - now.getMinutes()) * 60000 - now.getSeconds() * 1000;
  setTimeout(function() {
    if (STATE.soundUnlocked) {
      synthesiseBell();
      setTimeout(function() { synthesiseOm(3); }, 4500);
      STATE.bellsHeard++;
      updateStats();
      saveState();
      updateNextBellLabel();
    }
    setInterval(function() {
      if (STATE.soundUnlocked) {
        synthesiseBell();
        setTimeout(function() { synthesiseOm(3); }, 4500);
        STATE.bellsHeard++;
        updateStats();
        saveState();
        updateNextBellLabel();
      }
    }, 3600000); // every hour
  }, msUntilNextHour);
}

function updateNextBellLabel() {
  var el = document.getElementById('om-next-time');
  if (!el) return;
  if (!STATE.soundUnlocked) { el.textContent = 'Tap to unlock and ring'; return; }
  var now = new Date();
  var next = new Date(now);
  next.setHours(now.getHours() + 1, 0, 0, 0);
  var h = next.getHours(), m = '00';
  var ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  el.textContent = 'Next ring: ' + h + ':' + m + ' ' + ampm + ' · Tap to ring now';
}

/* ═══════════════════════════════════════════════════════════
   SECTION 4 · STREAK LOGIC
   Rules:
   – New user: streak = 0
   – First activity today sets lastActiveDate = today, streak = 1
   – If lastActiveDate = yesterday, streak++
   – If lastActiveDate < yesterday, streak = 1 (reset)
   – Same day repeated activities: streak unchanged
   ═══════════════════════════════════════════════════════════ */
function todayStr() {
  return new Date().toISOString().split('T')[0];
}

function yesterdayStr() {
  var d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().split('T')[0];
}

/* Call this whenever user completes any meaningful action */
function recordActivity() {
  var today = todayStr();

  if (STATE.lastActiveDate === today) {
    // Already counted today — just increment todayDone
    STATE.todayDone++;
  } else if (STATE.lastActiveDate === yesterdayStr()) {
    // Consecutive day — increment streak
    STATE.streak++;
    STATE.lastActiveDate = today;
    STATE.todayDone = 1;
  } else {
    // First ever OR missed a day — reset / start
    STATE.streak = STATE.streak === 0 ? 1 : 1; // reset to 1 on miss
    STATE.lastActiveDate = today;
    STATE.todayDone = 1;
  }

  updateStats();
  saveState();
}

function updateStats() {
  setText('stat-done',     STATE.todayDone);
  setText('stat-streak',   '🔥 ' + STATE.streak);
  setText('stat-bells',    STATE.bellsHeard);
  setText('stat-sessions', STATE.sessionsTotal);
  setText('focus-sessions',STATE.sessionsTotal);
  setText('focus-streak',  '🔥 ' + STATE.streak);
  var progBadge = document.getElementById('prog-day-badge');
  if (progBadge) progBadge.textContent = 'Day ' + STATE.progDay;
}

/* ═══════════════════════════════════════════════════════════
   SECTION 5 · NAVIGATION
   ═══════════════════════════════════════════════════════════ */
function go(screenId) {
  document.querySelectorAll('.screen').forEach(function(s) { s.classList.remove('active'); });
  document.querySelectorAll('.nav-btn').forEach(function(b) { b.classList.remove('active'); });
  var sc = document.getElementById('screen-' + screenId);
  if (sc) sc.classList.add('active');
  var nb = document.getElementById('nav-' + screenId);
  if (nb) nb.classList.add('active');
  window.scrollTo(0, 0);
  // Render dynamic content when switching to screens
  if (screenId === 'dina')       renderDinacharya();
  if (screenId === 'journal')    renderJournal();
  if (screenId === 'programme')  renderProgramme();
}

/* ═══════════════════════════════════════════════════════════
   SECTION 6 · ONBOARDING — MULTI-SELECT UX
   ═══════════════════════════════════════════════════════════ */

/* Multi-select toggle: any number of options selectable */
function obMultiToggle(el, groupKey) {
  el.classList.toggle('selected');
  updateSelectionCount(groupKey);
}

/* Single-select: only one option at a time */
function obSingleSelect(el, groupKey) {
  var parent = el.closest('.ob-options');
  if (parent) {
    parent.querySelectorAll('.ob-opt').forEach(function(o) { o.classList.remove('selected'); });
  }
  el.classList.add('selected');
}

/* Dosha card toggle (multi-select) */
function obDoshaToggle(card) {
  card.classList.toggle('selected');
  updateDoshaComboDisplay();
}

/* Tradition: strict single-select */
function obTradSelect(card) {
  var grid = document.getElementById('tradition-group');
  if (grid) grid.querySelectorAll('.ob-grid-card').forEach(function(c) { c.classList.remove('selected'); });
  card.classList.add('selected');
  updateSelectionCount('tradition');
}

/* Update the "(N selected)" counter below a group */
function updateSelectionCount(groupKey) {
  var ids = {
    intentions: 'intentions-count',
    traits:     'traits-count',
    tradition:  'tradition-count'
  };
  var groupIds = {
    intentions: 'intentions-group',
    traits:     'traits-group'
  };

  if (groupKey === 'tradition') {
    var tradEl = document.getElementById('tradition-count');
    var selected = document.querySelectorAll('#tradition-group .ob-grid-card.selected');
    if (tradEl) {
      if (selected.length) {
        tradEl.textContent = '✓ ' + selected[0].querySelector('.ob-grid-name').textContent + ' selected';
        tradEl.classList.add('has-selection');
      } else {
        tradEl.textContent = 'Choose one tradition';
        tradEl.classList.remove('has-selection');
      }
    }
    return;
  }

  var countElId = ids[groupKey];
  var groupElId = groupIds[groupKey];
  if (!countElId || !groupElId) return;

  var count = document.querySelectorAll('#' + groupElId + ' .ob-opt.selected').length;
  var el    = document.getElementById(countElId);
  if (!el) return;

  if (count === 0) {
    el.textContent = 'Select all that apply';
    el.classList.remove('has-selection');
  } else {
    el.textContent = '✓ ' + count + ' selected';
    el.classList.add('has-selection');
  }
}

/* Update the dosha combination label */
function updateDoshaComboDisplay() {
  var selected = document.querySelectorAll('#dosha-select-group .dosha-card.selected');
  var display  = document.getElementById('dosha-combo-display');
  if (!display) return;

  if (selected.length === 0) {
    display.textContent = 'Your combination will appear here';
    return;
  }

  var names = [];
  selected.forEach(function(c) { names.push(c.dataset.dosha.charAt(0).toUpperCase() + c.dataset.dosha.slice(1)); });

  var label = names.join('-');
  var desc  = DOSHA_COMBO_LABELS[names.map(function(n){return n.toLowerCase();}).sort().join('-')] || 'Your unique combination';
  display.textContent = '✦ ' + label + ' — ' + desc;
}

/* Add points to dosha scores (called from step 3 / 4 / 5 options) */
function obScore(dosha, pts) {
  STATE.doshaScores[dosha] = (STATE.doshaScores[dosha] || 0) + pts;
}

/* ── Advance / back steps ── */
function obNext(step) {
  // Collect data from current step before advancing
  collectStepData(step);

  document.getElementById('os' + step).classList.remove('active');
  var nextEl = document.getElementById('os' + (step + 1));
  if (nextEl) nextEl.classList.add('active');

  updateDot(step, 'done');
  updateDot(step + 1, 'active');

  // Pre-select the quiz-calculated doshas on step 6
  if (step + 1 === 6) preselectCalculatedDoshas();
}

function obBack(step) {
  document.getElementById('os' + step).classList.remove('active');
  document.getElementById('os' + (step - 1)).classList.add('active');
  updateDot(step, 'none');
  updateDot(step - 1, 'active');
}

function updateDot(index, state) {
  var dot = document.getElementById('od' + index);
  if (!dot) return;
  dot.classList.remove('active', 'done');
  if (state === 'done')   dot.classList.add('done');
  if (state === 'active') dot.classList.add('active');
}

/* Collect answers from each step into STATE */
function collectStepData(step) {
  if (step === 0) {
    var nameEl = document.getElementById('ob-name');
    STATE.userName = (nameEl && nameEl.value.trim()) || 'Friend';
  }
  if (step === 1) {
    STATE.intentions = getMultiSelected('intentions-group');
  }
  if (step === 2) {
    STATE.traits = getMultiSelected('traits-group');
    // Infer dosha tendency from traits
    if (STATE.traits.indexOf('overthinker') !== -1) obScore('vata', 1);
    if (STATE.traits.indexOf('driven')      !== -1) obScore('pitta', 1);
    if (STATE.traits.indexOf('steady')      !== -1) obScore('kapha', 1);
    if (STATE.traits.indexOf('foggy')       !== -1) obScore('kapha', 1);
  }
}

function getMultiSelected(groupId) {
  var keys = [];
  document.querySelectorAll('#' + groupId + ' .ob-opt.selected').forEach(function(o) {
    // derive key from title text — simplified
    var t = o.querySelector('.ob-opt-title');
    if (t) keys.push(t.textContent.toLowerCase().replace(/[\s\/]+/g,'_').substring(0,20));
  });
  return keys;
}

/* Pre-select doshas from scoring on step 6 */
function preselectCalculatedDoshas() {
  var s = STATE.doshaScores;
  var max = Math.max(s.vata, s.pitta, s.kapha);
  if (max === 0) return; // no answers yet
  var threshold = max * 0.7; // select doshas within 70% of the top score

  ['vata', 'pitta', 'kapha'].forEach(function(d) {
    if (s[d] >= threshold) {
      var card = document.querySelector('.dosha-card[data-dosha="' + d + '"]');
      if (card && !card.classList.contains('selected')) card.classList.add('selected');
    }
  });
  updateDoshaComboDisplay();
}

/* ── FINISH onboarding ── */
function obFinish() {
  // Collect tradition
  var tradCard = document.querySelector('#tradition-group .ob-grid-card.selected');
  STATE.tradition = tradCard ? (tradCard.dataset.trad || 'universal') : 'universal';

  // Collect dosha selections
  var selectedDoshas = [];
  document.querySelectorAll('#dosha-select-group .dosha-card.selected').forEach(function(c) {
    selectedDoshas.push(c.dataset.dosha);
  });
  if (selectedDoshas.length === 0) {
    // Fall back to highest score
    var s = STATE.doshaScores;
    var top = Object.keys(s).reduce(function(a,b){ return s[a]>s[b]?a:b; });
    selectedDoshas = [top];
  }
  STATE.doshaCombo = selectedDoshas.sort(); // e.g. ['pitta','vata']
  STATE.onboardDone = true;
  STATE.streak = 0;         // FIX: always starts at 0
  STATE.lastActiveDate = '';
  STATE.todayDone = 0;
  STATE.bellsHeard = 0;
  STATE.sessionsTotal = 0;
  saveState();

  // Build result card
  buildResultCard();

  // Show result step
  for (var i = 0; i <= 7; i++) {
    var st = document.getElementById('os' + i);
    if (st) st.classList.remove('active');
    updateDot(i, 'done');
  }
  var res = document.getElementById('os-result');
  if (res) res.classList.add('active');
}

function buildResultCard() {
  var combo  = STATE.doshaCombo;
  var comboKey = combo.join('-');
  var data   = getDoshaComboData(combo);
  var scores = STATE.doshaScores;
  var total  = scores.vata + scores.pitta + scores.kapha + 0.01;
  var pv = Math.round(scores.vata  / total * 100);
  var pp = Math.round(scores.pitta / total * 100);
  var pk = Math.round(scores.kapha / total * 100);

  var highlightHTML = data.highlights.map(function(h) {
    return '<div class="dr-h-item"><div class="dr-h-dot"></div><div>' + h + '</div></div>';
  }).join('');

  var html = [
    '<div class="dr-badge ' + data.badgeClass + '">✦ ' + data.badge + '</div>',
    '<div class="dr-title">Namaste, ' + STATE.userName + '</div>',
    '<div class="dr-desc">' + data.description + '</div>',
    '<div class="dr-bars">',
      '<div class="dr-bar"><div class="dr-bar-label">Vata</div><div class="dr-bar-track"><div class="dr-bar-fill" style="background:var(--vata-c);width:' + pv + '%"></div></div></div>',
      '<div class="dr-bar"><div class="dr-bar-label">Pitta</div><div class="dr-bar-track"><div class="dr-bar-fill" style="background:var(--pitta-c);width:' + pp + '%"></div></div></div>',
      '<div class="dr-bar"><div class="dr-bar-label">Kapha</div><div class="dr-bar-track"><div class="dr-bar-fill" style="background:var(--kapha-c);width:' + pk + '%"></div></div></div>',
    '</div>',
    '<div class="dr-highlights">',
      '<div class="dr-h-title">Your personalised guidance</div>',
      highlightHTML,
    '</div>'
  ].join('');

  var div = document.getElementById('dosha-result-html');
  if (div) div.innerHTML = html;
}

function closeOnboard() {
  var ov = document.getElementById('onboard');
  if (ov) ov.classList.remove('visible');
  applyProfileToApp();
  go('home');
}

/* ═══════════════════════════════════════════════════════════
   SECTION 7 · DOSHA COMBO DATA
   Covers all 7 combinations: V P K VP PK VK VPK
   ═══════════════════════════════════════════════════════════ */
var DOSHA_COMBO_LABELS = {
  'vata':           'Air & Ether dominant',
  'pitta':          'Fire & Water dominant',
  'kapha':          'Earth & Water dominant',
  'vata-pitta':     'Air meets Fire — creative intensity',
  'pitta-vata':     'Air meets Fire — creative intensity',
  'kapha-pitta':    'Fire meets Earth — driven stability',
  'pitta-kapha':    'Fire meets Earth — driven stability',
  'kapha-vata':     'Air meets Earth — sensitive groundedness',
  'vata-kapha':     'Air meets Earth — sensitive groundedness',
  'kapha-pitta-vata':'Tridoshic — all three in play'
};

function getDoshaComboData(combo) {
  var key = combo.slice().sort().join('-');

  var DATA = {
    'vata': {
      badge:'Vata-dominant', badgeClass:'dr-v',
      description: 'You are governed by Air and Ether — creative, quick, light, and sensitive. When balanced you are imaginative and expressive. When imbalanced, anxiety, scattered attention, and irregular digestion arise. Your medicine is warmth, regularity, and nourishment.',
      highlights: [
        'Wake and sleep at exactly the same time every day — regularity is your primary medicine',
        'Eat warm, cooked, oily, grounding foods: sesame, ghee, root vegetables, soups',
        'Practice gentle yoga, slow walking, and restorative postures — avoid cold, wind, and high-intensity exercise',
        'Ashwagandha, shatavari, ginger, sesame oil are your herbal allies',
        'Daily Abhyanga (warm oil self-massage) — the single most stabilising Vata practice'
      ]
    },
    'pitta': {
      badge:'Pitta-dominant', badgeClass:'dr-p',
      description: 'You are governed by Fire and Water — sharp, focused, driven, and transformative. When balanced you are courageous and brilliant. When imbalanced, inflammation, irritability, and the need to overachieve appear. Your medicine is coolness, moderation, and playfulness.',
      highlights: [
        'Cooling foods: cucumber, coriander, coconut, sweet fruits, fennel, rose water',
        'Avoid chilli, fried foods, alcohol, and working through the midday heat',
        'Moderate exercise — swimming, cycling, yoga in the cool of morning or evening',
        'Brahmi, shatavari, neem, amalaki — your cooling, anti-inflammatory allies',
        'Sheetali pranayama (cooling breath) daily — your most targeted Pitta practice'
      ]
    },
    'kapha': {
      badge:'Kapha-dominant', badgeClass:'dr-k',
      description: 'You are governed by Earth and Water — stable, nourishing, loyal, and enduring. When balanced you are compassionate, strong, and deeply present. When imbalanced, lethargy, congestion, and heaviness appear. Your medicine is stimulation, warmth, and variety.',
      highlights: [
        'Wake before 6 AM every day without exception — sleeping through the Kapha morning increases imbalance',
        'Light, warm, spiced foods: ginger, black pepper, turmeric, bitter greens. Reduce dairy, sweet, and heavy foods',
        'Vigorous daily movement — running, dancing, aerobics. Kapha needs fire and freshness every day',
        'Trikatu, ginger, turmeric, honey — your stimulating and energising allies',
        'Vary your routine constantly — same routine every day increases Kapha. Novelty is medicine.'
      ]
    },
    'vata-pitta': {
      badge:'Vata-Pitta', badgeClass:'dr-vp',
      description: 'You carry both Air and Fire — the combination of creative anxiety and driven intensity. You move fast, think fast, and burn out fast. When balanced you are inspired and decisive. When imbalanced, you are simultaneously scattered AND irritable. Grounding warmth and strategic cooling are both your medicine.',
      highlights: [
        'Regular mealtimes are essential — Vata thrives on rhythm; Pitta on fuel. Skip neither',
        'Warm but not spicy foods: basmati rice, cooked vegetables, mild spices like cumin and coriander',
        'Yoga and swimming over running — vigorous enough for Pitta, gentle enough for Vata',
        'Ashwagandha for Vata anxiety; Brahmi for Pitta intensity — both can be taken together',
        'Nadi Shodhana (alternate nostril breath) daily — balances both doshas simultaneously'
      ]
    },
    'kapha-pitta': {
      badge:'Pitta-Kapha', badgeClass:'dr-pk',
      description: 'You carry Fire and Earth — the combination of intensity and stability. You are driven but grounded, ambitious but loyal. When balanced you achieve with grace. When imbalanced you can become stubborn, possessive, and overheated. Stimulation without aggravation is your medicine.',
      highlights: [
        'Active mornings are essential — Kapha needs movement; Pitta provides the drive. Use it',
        'Light, cooling, well-spiced foods: bitter greens, legumes, light grains. Avoid heavy and spicy',
        'Vigorous morning exercise in cool weather — Pitta provides motivation, Kapha needs to burn',
        'Neem, turmeric, trikatu — address both Pitta heat and Kapha congestion',
        'Bhramari breath for Pitta anger; Kapalbhati for Kapha sluggishness — alternate based on the day'
      ]
    },
    'vata-kapha': {
      badge:'Vata-Kapha', badgeClass:'dr-vk',
      description: 'You carry Air and Earth — the paradoxical combination of lightness and heaviness, creativity and inertia. You can be both restless AND stuck. When balanced you are deeply grounded yet imaginatively free. Your medicine is warm stimulation with consistent routine.',
      highlights: [
        'A fixed daily schedule with varied content — Vata needs routine; Kapha needs novelty. Give both',
        'Warm, slightly spiced, light foods — the middle path between Vata nourishment and Kapha lightness',
        'Brisk walking outdoors daily — gentle enough for Vata, active enough for Kapha',
        'Ginger and ashwagandha together: warming adaptogen for both Vata and Kapha',
        'Surya Namaskar: warming, grounding, rhythmic — the perfect Vata-Kapha practice'
      ]
    },
    'kapha-pitta-vata': {
      badge:'Tridoshic', badgeClass:'dr-vpk',
      description: 'You carry all three doshas in significant measure — a rare tridoshic constitution. You are highly adaptable but also susceptible to whichever dosha the season, diet, or stress tips out of balance. Your medicine is seasonal awareness, daily check-in, and seasonal dietary adjustment.',
      highlights: [
        'Follow seasonal dinacharya: Vata-pacifying in autumn, Pitta-cooling in summer, Kapha-stimulating in spring',
        'Check in with your mood and body daily — your balance shifts more than single-dosha types',
        'Moderate all practices: neither too intense nor too gentle. The middle path is yours.',
        'Triphala daily — the tridoshic herbal formula that supports all three doshas simultaneously',
        'Use the mood selector in your dinacharya every day — it is your most accurate daily guide'
      ]
    }
  };

  return DATA[key] || DATA['pitta'];
}

/* ═══════════════════════════════════════════════════════════
   SECTION 8 · APPLY PROFILE TO APP UI
   Called after onboarding closes and on every app load
   ═══════════════════════════════════════════════════════════ */
function applyProfileToApp() {
  if (!STATE.onboardDone) return;

  var name  = STATE.userName || 'Friend';
  var combo = STATE.doshaCombo;
  var trad  = STATE.tradition;

  // Greeting
  setText('homeGreeting', 'Namaste, ' + name + ' ✦');

  // Dosha pills
  var pillsDiv = document.getElementById('doshaDisplay');
  if (pillsDiv) {
    pillsDiv.innerHTML = combo.map(function(d) {
      return '<span class="dpill dp-' + d.charAt(0) + '">' + d.charAt(0).toUpperCase() + d.slice(1) + '</span>';
    }).join('');
  }

  // Tradition badge and daily verse on home
  applyTraditionTheme(trad);

  // Dinacharya hero
  var data = getDoshaComboData(combo);
  setText('dina-title', 'Dinacharya · ' + combo.map(function(d){ return d.charAt(0).toUpperCase()+d.slice(1); }).join('-'));
  setText('dina-sub', data.badge + ' · ' + (STATE.traits.length ? STATE.traits[0].replace(/_/g,' ') : 'personalised'));

  // Dosha bars
  var scores = STATE.doshaScores;
  var total  = Math.max(scores.vata + scores.pitta + scores.kapha, 1);
  setStyle('vata-bar',  'width', Math.round(scores.vata  / total * 100) + '%');
  setStyle('pitta-bar', 'width', Math.round(scores.pitta / total * 100) + '%');
  setStyle('kapha-bar', 'width', Math.round(scores.kapha / total * 100) + '%');

  // Stats
  updateStats();
  updateNextBellLabel();

  // Programme day badge
  var progBadge = document.getElementById('prog-day-badge');
  if (progBadge) progBadge.textContent = 'Day ' + STATE.progDay;

  // Sound unlock notice
  if (STATE.soundUnlocked) hideSoundNotice();
}

/* ═══════════════════════════════════════════════════════════
   SECTION 9 · TRADITION THEME
   Strictly applies one tradition's content everywhere.
   NO cross-tradition content.
   ═══════════════════════════════════════════════════════════ */

/* ── TRADITION CONTENT LIBRARY ────────────────────────────
   Each tradition has its own daily verse, journal prompts,
   and programme content. Nothing bleeds between them.
   ─────────────────────────────────────────────────────── */
var TRADITION_CONTENT = {

  hindu: {
    name: 'Hindu / Vedantic',
    badgeClass: 'tb-hindu',
    verseCardClass: 'dv-hindu',
    srcClass: 'psrc-h',
    tradLabel: '🪔 Hindu / Vedantic',
    morningVerse: {
      label:  'Hindu tradition · Morning verse',
      text:   '"Karagre vasate Lakshmi, Karamadhye Saraswati, Karamule tu Govinda — behold your hands at dawn."',
      source: 'Traditional · recite before rising'
    },
    journalPrompts: [
      { icon:'🙏', src:'psrc-h', label:'Sankalpa · Hindu',
        q: '"What is your sankalpa — your deepest intention — for today? Not your to-do list. Your truest resolve."',
        ctx: 'Sankalpa is the Sanskrit word for the heart\'s deepest vow. Setting it at dawn aligns action with dharma, not obligation.' },
      { icon:'⚡', src:'psrc-h', label:'Karmanye vadhikaraste · Gita 2.47',
        q: '"What are you trying to control right now that is not within your control? What becomes possible if you release it — just for today?"',
        ctx: 'You have right to action, never to its fruits. This prompt makes Gita 2.47 personal and immediate.' },
      { icon:'✦', src:'psrc-h', label:'Svadhyaya · Patanjali',
        q: '"If your life were your message to the world — what message are you sending right now? Is it the one you intend?"',
        ctx: 'Svadhyaya — self-study — is one of Patanjali\'s Niyamas. Return to this question monthly.' },
      { icon:'🔥', src:'psrc-h', label:'Agni · Ayurveda',
        q: '"Where in your body are you holding tension or heaviness right now? What is your agni — your inner fire — saying?"',
        ctx: 'Ayurveda teaches that disease begins in an unattended mind. The body speaks first.' },
      { icon:'🌅', src:'psrc-h', label:'Dharma question',
        q: '"What is your role in the world right now — not your job, but your dharma? What does life ask of you?"',
        ctx: 'Dharma is the action that arises from your deepest nature. This question points toward it.' }
    ],
    eveningVerse: {
      text: '"Asato ma sadgamaya. Tamaso ma jyotirgamaya. Mrityorma amritam gamaya. OM shanti shanti shanti."',
      source: 'Brihadaranyaka Upanishad 1.3.28'
    }
  },

  thay: {
    name: 'Thich Nhat Hanh',
    badgeClass: 'tb-thay',
    verseCardClass: 'dv-thay',
    srcClass: 'psrc-t',
    tradLabel: '🌸 Plum Village',
    morningVerse: {
      label:  'Morning gatha · Plum Village',
      text:   '"Waking up this morning, I smile. Twenty-four brand new hours are before me. I vow to live fully in each moment, and to look at all beings with eyes of compassion."',
      source: 'Thich Nhat Hanh · Present Moment, Wonderful Moment'
    },
    journalPrompts: [
      { icon:'🌅', src:'psrc-t', label:'Morning vow · Plum Village',
        q: '"Twenty-four brand new hours are before you. What do you vow — not plan, but vow — to bring to this day?"',
        ctx: 'Thay begins every morning with a smile and a vow. Not a schedule — a quality of being.' },
      { icon:'🌸', src:'psrc-t', label:'Interbeing · Thich Nhat Hanh',
        q: '"Look at your hand. Name five things that are \'not-you\' contained within it right now. What does this tell you about who you are?"',
        ctx: 'Your hand contains the food you ate, the water you drank, your parents, the sun, the soil. Nothing exists alone.' },
      { icon:'🌱', src:'psrc-t', label:'Begin Anew · Plum Village',
        q: '"Begin Anew: What do I appreciate in someone today? What do I regret? What hurt me? What do I need?"',
        ctx: 'The Plum Village Begin Anew ceremony has four movements: appreciation, regret, hurt, and need.' },
      { icon:'🔔', src:'psrc-t', label:'Bell of mindfulness',
        q: '"The bell rings. Stop. Breathe. Where were you just now — past, future, or present? What brought you back?"',
        ctx: 'The bell is not an interruption — it is an invitation to return home. Each ring is a fresh beginning.' },
      { icon:'🌊', src:'psrc-t', label:'Interbeing · food practice',
        q: '"Who is in the food you ate today? The water you drank? Trace one thing back to all its sources."',
        ctx: 'The rice on your plate contains the farmer, the rain, the soil, the seed, the sun. You are in deep relationship with all of life.' }
    ],
    eveningVerse: {
      text: '"Listen, listen. This wonderful sound brings me back to my true home."',
      source: 'Plum Village bell gatha'
    }
  },

  buddhist: {
    name: 'Buddhist',
    badgeClass: 'tb-buddhist',
    verseCardClass: 'dv-buddhist',
    srcClass: 'psrc-b',
    tradLabel: '☸ Buddhist',
    morningVerse: {
      label:  'Buddhist morning practice',
      text:   '"May I be happy. May I be well. May I be peaceful. May I be free from suffering." — Metta Sutta',
      source: 'Loving-kindness meditation · begin here each morning'
    },
    journalPrompts: [
      { icon:'☸', src:'psrc-b', label:'Metta · Loving-kindness',
        q: '"Towards whom are you finding it hardest to feel compassion right now? Can you begin with just a moment of wishing them well — genuinely?"',
        ctx: 'The Buddha taught that metta for difficult people is where the practice truly begins.' },
      { icon:'🌬', src:'psrc-b', label:'Anicca · Impermanence',
        q: '"What are you clinging to right now that you know, in your heart, is changing? What would it feel like to hold it lightly?"',
        ctx: 'All conditioned things are impermanent. Suffering arises from clinging to what cannot stay.' },
      { icon:'🎯', src:'psrc-b', label:'Right intention · Noble Eightfold Path',
        q: '"What intention — renunciation, goodwill, or harmlessness — can you bring to the most difficult thing you face today?"',
        ctx: 'Right intention is one of the three aspects of wisdom in the Eightfold Path. It is chosen, not waited for.' },
      { icon:'💧', src:'psrc-b', label:'Vipassana · insight',
        q: '"Sit quietly. Notice one thought arise and pass. Can you see it as a cloud crossing the sky — not you, but observed by you?"',
        ctx: 'Vipassana insight: you are the awareness watching thoughts, not the thoughts themselves.' },
      { icon:'🙏', src:'psrc-b', label:'Three Jewels',
        q: '"I take refuge in the Buddha — my own capacity for awakening. What did you discover about yourself today that points toward your own freedom?"',
        ctx: 'The Three Jewels: Buddha (awakening), Dharma (truth), Sangha (community). Each contains the teaching.' }
    ],
    eveningVerse: {
      text: '"May all beings be happy, may all beings be free from suffering, may all beings know peace."',
      source: 'Metta Sutta · evening dedication of merit'
    }
  },

  universal: {
    name: 'Universal',
    badgeClass: 'tb-universal',
    verseCardClass: 'dv-universal',
    srcClass: 'psrc-u',
    tradLabel: '✦ Universal',
    morningVerse: {
      label:  'Universal · Morning reflection',
      text:   '"The present moment is the only home we ever have. Before this day begins — breathe once, fully. You are here."',
      source: 'Universal mindfulness practice · no belief required'
    },
    journalPrompts: [
      { icon:'🌿', src:'psrc-u', label:'Presence · Universal',
        q: '"Where in your body are you holding tension right now? What is it trying to tell you before the day begins?"',
        ctx: 'The body always speaks first. Emotion lives in the body before it becomes thought.' },
      { icon:'🕯', src:'psrc-u', label:'Gratitude · evidence-based',
        q: '"Name three specific things today — however small — that you would not have chosen to be without."',
        ctx: 'Specificity transforms gratitude. Three detailed small things outperform ten vague ones every time.' },
      { icon:'🌱', src:'psrc-u', label:'Identity question',
        q: '"Who are you becoming through your daily choices right now? Is that the person you want to be?"',
        ctx: 'Every action is a vote for the identity you are building. This question makes that visible.' },
      { icon:'🌊', src:'psrc-u', label:'Control and release',
        q: '"What are you trying to control right now that is genuinely outside your control? What becomes available when you release it?"',
        ctx: 'The Stoics, the Gita, and Thay all point to the same truth: work with your response, not the outcome.' },
      { icon:'💧', src:'psrc-u', label:'Connection · Science of belonging',
        q: '"Who in your life needs to hear from you today? What would you say if you knew you had nothing to prove?"',
        ctx: 'Belonging is a fundamental human need. Research shows that reaching out benefits the giver as much as the receiver.' }
    ],
    eveningVerse: {
      text: '"Today is complete. What was done is done. What was left undone rests now. You may rest too."',
      source: 'Universal evening reflection'
    }
  }

};

function applyTraditionTheme(trad) {
  var content = TRADITION_CONTENT[trad] || TRADITION_CONTENT.universal;

  // Home verse card
  var card   = document.getElementById('home-verse-card');
  var label  = document.getElementById('home-verse-label');
  var text   = document.getElementById('home-verse-text');
  var source = document.getElementById('home-verse-source');

  if (card)   { card.className = 'dv-card ' + content.verseCardClass; }
  if (label)  label.textContent  = content.morningVerse.label;
  if (text)   text.textContent   = content.morningVerse.text;
  if (source) source.textContent = content.morningVerse.source;

  // Tradition badge (add one to hero if not present)
  var hero = document.querySelector('.home-hero');
  if (hero) {
    var badge = hero.querySelector('.tradition-badge');
    if (!badge) {
      badge = document.createElement('div');
      badge.className = 'tradition-badge';
      hero.insertBefore(badge, hero.querySelector('.dosha-pills'));
    }
    badge.className = 'tradition-badge ' + content.badgeClass;
    badge.textContent = content.tradLabel;
  }

  // Journal label
  setText('journal-tradition-label', content.tradLabel + ' · tradition-specific prompts');
}

/* ═══════════════════════════════════════════════════════════
   SECTION 10 · ADAPTIVE DINACHARYA RENDERER
   Generates timeline from dosha combo + mood + tradition.
   No static HTML for timeline cards — all generated here.
   ═══════════════════════════════════════════════════════════ */

/* ── MOOD DATA — all 6 moods × all fields ── */
var MOOD_DATA = {

  balanced: {
    notice: '',
    walkSub: 'Mindful pace · walking gatha · intention-setting',
    walkPills: ['sp-jade:Walking gatha', 'sp-gd:Set intention before stepping out'],
    foodSub: 'Dosha-appropriate meal · gratitude prayer · eat slowly',
    foodPills: ['sp-gd:Eat with awareness', 'sp-sg:No screen during meal', 'sp-jade:Food prayer'],
    workTag: 'For work · action without attachment to results',
    workDeva: 'कर्मण्येवाधिकारस्ते मा फलेषु कदाचन।',
    workVerse: '"Yogasthah kuru karmani — be steadfast in yoga, perform your duty." — Gita 2.48',
    workMeaning: 'Do the work fully. Release the result completely.',
    workPills: ['sp-sf:Focus block', 'sp-sf:Hourly bell', 'sp-jade:Mindful breaks'],
    lunchSub: 'Largest meal · agni at peak · 10 min rest after',
    lunchPills: ['sp-gd:Eat at noon', 'sp-sg:Rest 10 min', 'sp-jade:No screen'],
    afternoonTitle: 'Afternoon reset',
    afternoonSub: 'Warm water · 5 min walk · 3 conscious breaths',
    afternoonVerse: '"Breathing in, I calm my body. Breathing out, I smile." — Thay',
    afternoonMeaning: 'Three breaths resets the nervous system. Five minutes of walking completes the renewal.'
  },

  anxious: {
    notice: '✦ Anxious mood — dinacharya adapted to grounding and calming',
    walkSub: 'Slow, gentle walk · nature · no pace goal · bare feet on earth if possible',
    walkPills: ['sp-jade:Slow gatha walk', 'sp-sf:No destination', 'sp-sg:Nature sounds'],
    foodSub: 'Vata-pacifying · warm, oily, grounding foods · no caffeine today',
    foodPills: ['sp-gd:Warm oat porridge', 'sp-gd:Ghee and sesame', 'sp-sg:No caffeine'],
    workTag: 'For anxiety · you are unbreakable beneath this',
    workDeva: 'नैनं छिन्दन्ति शस्त्राणि नैनं दहति पावकः।',
    workVerse: '"Breathing in, I know I am breathing in." — Thay. The simplest instruction. The most complete.',
    workMeaning: 'On anxious days: one task at a time. The Gita reminds you — the soul is untouchable.',
    workPills: ['sp-jade:One task only', 'sp-sf:Bhramari breath breaks', 'sp-sg:No multitasking'],
    lunchSub: 'Light, warm, simple lunch · no spicy · rest 15 min after',
    lunchPills: ['sp-gd:Kitchari or dal', 'sp-gd:Warm spiced milk', 'sp-jade:15 min rest'],
    afternoonTitle: 'Bhramari breath · grounding',
    afternoonSub: 'Bhramari 5 min · warm herbal tea · sit on the floor if you can',
    afternoonVerse: '"The present moment is filled with joy and happiness. If you are attentive, you will see it." — Thay',
    afternoonMeaning: 'Bhramari activates the vagus nerve through vibration. 5 minutes measurably reduces cortisol.'
  },

  angry: {
    notice: '✦ Irritable mood — cooling Pitta practices prioritised',
    walkSub: 'Walk in shade · cooling intention · no competitive pace',
    walkPills: ['sp-jade:Shaded walk', 'sp-sf:Cooling breath', 'sp-gd:Coconut water after'],
    foodSub: 'Pitta-cooling only · no spicy, sour or fermented foods · sweet and bitter today',
    foodPills: ['sp-gd:Sweet fruits', 'sp-gd:Bitter greens', 'sp-sg:No chilli today'],
    workTag: 'For anger · see the chain before it pulls you',
    workDeva: 'क्रोधाद्भवति सम्मोहः सम्मोहात्स्मृतिविभ्रमः।',
    workVerse: '"From anger comes delusion. From delusion, loss of reason. From loss of reason — one is lost." — Gita 2.63',
    workMeaning: 'Before any reactive action: three breaths. Name the emotion. Then choose your response.',
    workPills: ['sp-jade:No reactive emails', 'sp-sf:Sheetali breath', 'sp-gd:Pause before replying'],
    lunchSub: 'Cooling foods only · eat slowly · short walk after',
    lunchPills: ['sp-gd:Cooling foods only', 'sp-jade:Walk after', 'sp-sg:No heated discussion'],
    afternoonTitle: 'Sheetali breath · cooling Pitta fire',
    afternoonSub: 'Sheetali 5 min · cold water · no screens',
    afternoonVerse: '"Stop. Look deeply. Act from understanding — not from reaction." — Thay',
    afternoonMeaning: 'Sheetali (rolled-tongue inhale) is the Ayurvedic prescription for Pitta fire. Body cools, mind follows.'
  },

  low: {
    notice: '✦ Low energy — stimulating Kapha-balancing practices surfaced',
    walkSub: 'Brisk walk · morning sun · vigorous pace · no shade today',
    walkPills: ['sp-sf:Brisk pace', 'sp-sf:Morning sun', 'sp-gd:Ginger tea first'],
    foodSub: 'Kapha-stimulating · light, spiced, warm · skip heavy breakfast',
    foodPills: ['sp-gd:Ginger lemon water', 'sp-sf:Light warm food', 'sp-sg:No heavy breakfast'],
    workTag: 'For low energy · elevate yourself — by yourself',
    workDeva: 'उद्धरेदात्मनात्मानं नात्मानमवसादयेत्।',
    workVerse: '"Elevate yourself by yourself. Do not let yourself fall. The self is the friend of the self." — Gita 6.5',
    workMeaning: 'Low energy is a Kapha state. Prescription: movement, warmth, stimulation. Even 5 vigorous minutes shifts everything.',
    workPills: ['sp-sf:Change location', 'sp-sf:Kapalbhati break', 'sp-gd:Cold water splash'],
    lunchSub: 'Light, spiced lunch · no heavy carbs · 10 min walk after',
    lunchPills: ['sp-gd:Trikatu spice', 'sp-sf:Light dal', 'sp-jade:10 min walk'],
    afternoonTitle: 'Kapalbhati · energising breath',
    afternoonSub: 'Kapalbhati 3 min · brief vigorous movement · get outside',
    afternoonVerse: '"Waking up this morning, I smile." — Even now. The smile is an invitation, not a performance.',
    afternoonMeaning: 'Kapalbhati (60 rapid exhales) ignites the pranic fire. Follow with 5 minutes of any vigorous movement.'
  },

  grief: {
    notice: '✦ Heavy-hearted mood — gentle, nourishing practices offered',
    walkSub: 'Slow, tender walk · find one beautiful thing · no hurry at all',
    walkPills: ['sp-jade:No goal walk', 'sp-sf:Find one beauty', 'sp-sg:Sit if needed'],
    foodSub: 'Warm, nourishing, simple food · eat slowly · let yourself be fed today',
    foodPills: ['sp-gd:Warm soup or dal', 'sp-gd:Sweet soft foods', 'sp-jade:Eat with someone if possible'],
    workTag: 'For grief · what you love does not disappear — it transforms',
    workDeva: 'नैनं छिन्दन्ति शस्त्राणि नैनं दहति पावकः।',
    workVerse: '"No death, no fear. The cloud never dies — it becomes rain. Nothing is ever lost." — Thich Nhat Hanh',
    workMeaning: 'On grief days the Gita and Thay agree: what you love does not disappear. It transforms. You are held.',
    workPills: ['sp-jade:Gentle tasks only', 'sp-sf:Metta practice', 'sp-sg:Be very kind to yourself'],
    lunchSub: 'Nourishing lunch · eat with someone · no rushing',
    lunchPills: ['sp-gd:Nourishing warm meal', 'sp-jade:Eat with company', 'sp-sg:Rest after'],
    afternoonTitle: 'Loving-kindness meditation',
    afternoonSub: 'Metta 10 min · "May I be happy. May I be well. May I be at peace."',
    afternoonVerse: '"Even as they strike you down — remember: man is not our enemy." — Thich Nhat Hanh',
    afternoonMeaning: 'Grief is love with nowhere to go. Begin Metta with yourself first. You cannot pour from an empty vessel.'
  },

  focused: {
    notice: '✦ Focused state — flow-sustaining practices surfaced',
    walkSub: 'Purposeful walk · set one sankalpa before stepping out',
    walkPills: ['sp-jade:Sankalpa walk', 'sp-sf:Clear intention', 'sp-sg:Mindful steps'],
    foodSub: 'Light but nourishing · fuel the focused state · no heavy grains',
    foodPills: ['sp-gd:Protein-rich', 'sp-gd:No heavy carbs', 'sp-jade:Eat with full awareness'],
    workTag: 'For deep focus · be steadfast in yoga — the Gita at its most precise',
    workDeva: 'योगस्थः कुरु कर्माणि सङ्गं त्यक्त्वा धनञ्जय।',
    workVerse: '"Be steadfast in yoga. Perform your duty, abandoning attachment to fruits." — Gita 2.48',
    workMeaning: 'You are already in the state. Protect it: no multitasking, no interruptions. One thing, completely.',
    workPills: ['sp-sf:Deep work block', 'sp-sf:No meetings if possible', 'sp-jade:Box breath between tasks'],
    lunchSub: 'Light lunch · return to focus quickly · 20 min break max',
    lunchPills: ['sp-gd:Light lunch', 'sp-jade:20 min break', 'sp-sg:Short walk'],
    afternoonTitle: 'Box breathing · maintain the thread',
    afternoonSub: 'Box breath 4 min · protect the afternoon focus window',
    afternoonVerse: '"I have arrived. I am home." — Even at 3 PM on a focused day, arrival is always available.',
    afternoonMeaning: 'Box breathing (4-4-4-4) maintains prefrontal cortex activation. Use at every break today.'
  }

};

/* Generate tradition-aware shloka for a card */
function getTraditionShloka(slot, mood) {
  var trad = STATE.tradition;
  var m    = MOOD_DATA[mood] || MOOD_DATA.balanced;

  var shlokas = {
    wake: {
      hindu:    { cls:'sm-gold', srcCls:'src-hindu', tag:'On waking · reverence',
                  deva:'कराग्रे वसते लक्ष्मीः करमध्ये सरस्वती।',
                  verse:'Karagre vasate Lakshmi, Karamadhye Saraswati, Karamule tu Govinda — behold your hands at dawn.',
                  meaning:'Before speaking, before the phone, consecrate your hands and the day that passes through them.' },
      thay:     { cls:'sm-jade', srcCls:'src-thay',  tag:'Morning gatha · Plum Village',
                  verse:'"Waking up this morning, I smile. Twenty-four brand new hours are before me. I vow to live fully in each moment."',
                  meaning:'Thay\'s morning gatha. The smile is not performance — it is an invitation to the day.' },
      buddhist: { cls:'sm-sky',  srcCls:'src-buddhist', tag:'Morning metta practice',
                  verse:'"May I be happy. May I be well. May I be peaceful. May I be free from suffering." — Metta Sutta',
                  meaning:'Begin with loving-kindness directed at yourself. Only then does it radiate outward.' },
      universal:{ cls:'sm-gold', srcCls:'src-both',   tag:'Universal morning reflection',
                  verse:'"Before this day begins — breathe once, fully. Notice that you are here. That you are alive. That is enough to begin."',
                  meaning:'No belief required. One conscious breath is a complete morning practice.' }
    },
    food: {
      hindu:    { cls:'sm-gold', srcCls:'src-hindu', tag:'Before eating · Brahmarpanam',
                  deva:'ब्रह्मार्पणं ब्रह्म हविर्ब्रह्माग्नौ ब्रह्मणा हुतम्।',
                  verse:'The act of offering is Brahman. The food is Brahman. The fire of digestion is Brahman.',
                  meaning:'Bhagavad Gita 4.24 — recite before every meal. Eating becomes yajna.' },
      thay:     { cls:'sm-jade', srcCls:'src-thay',  tag:'Five Contemplations · Plum Village',
                  verse:'"This food is a gift of the Earth, the sky, numerous living beings, and much hard work. May I eat with gratitude."',
                  meaning:'Recited before every meal at Plum Village. Eat slowly. Put the fork down between bites.' },
      buddhist: { cls:'sm-sky',  srcCls:'src-buddhist', tag:'Mindful eating · Buddhist practice',
                  verse:'"I eat this food not for pleasure, not for intoxication, but to sustain the body, to continue the practice."',
                  meaning:'Right consumption: eating to support practice, not to indulge craving.' },
      universal:{ cls:'sm-gold', srcCls:'src-both',   tag:'Gratitude before eating',
                  verse:'"Before eating — pause. Name one living thing that made this meal possible. Then eat with that awareness."',
                  meaning:'Mindful eating begins with one deliberate pause. Science confirms it improves digestion and reduces overeating.' }
    },
    work: {
      hindu:    { cls:'sm-saffron', srcCls:'src-hindu', tag: m.workTag,
                  deva: m.workDeva, verse: m.workVerse, meaning: m.workMeaning },
      thay:     { cls:'sm-jade',    srcCls:'src-thay',  tag: m.workTag,
                  verse: m.workVerse, meaning: m.workMeaning },
      buddhist: { cls:'sm-sky',     srcCls:'src-buddhist', tag:'Right effort · Noble Eightfold Path',
                  verse:'"Right effort means preventing unwholesome states from arising, abandoning those that have arisen, cultivating wholesome states." — Buddha',
                  meaning:'Your work block is Right Effort in action. Not suppression — conscious cultivation.' },
      universal:{ cls:'sm-gold',    srcCls:'src-both',  tag: m.workTag,
                  verse: m.workVerse, meaning: m.workMeaning }
    },
    evening: {
      hindu:    { cls:'sm-dark', srcCls:'src-hindu', tag:'Evening prayer · Asato ma',
                  deva:'असतो मा सद्गमय। तमसो मा ज्योतिर्गमय।',
                  verse:'Lead me from untruth to truth. From darkness to light. From fear of death to the knowledge of immortality.',
                  meaning:'Brihadaranyaka Upanishad 1.3.28 — the great prayer of becoming. Surrender the day here.' },
      thay:     { cls:'sm-jade', srcCls:'src-thay',  tag:'Evening · Begin Anew',
                  verse:'"Begin Anew: What do I appreciate? What do I regret? What hurt me? What do I need?" — Plum Village',
                  meaning:'The most healing evening practice. Four movements of honest self-reflection.' },
      buddhist: { cls:'sm-sky',  srcCls:'src-buddhist', tag:'Dedication of merit · evening',
                  verse:'"By this practice, may all beings be free from suffering. May all beings know peace."',
                  meaning:'Close each day by dedicating the benefit of your practice to all beings.' },
      universal:{ cls:'sm-dark', srcCls:'src-both',   tag:'Evening reflection',
                  verse:'"Today is complete. What was done is done. What was left undone rests now. You may rest too."',
                  meaning:'No tradition required to end a day with honesty and release.' }
    },
    sleep: {
      hindu:    { cls:'sm-jade', srcCls:'src-hindu', tag:'For sleep · peace in three layers',
                  deva:'ॐ शान्तिः शान्तिः शान्तिः',
                  verse:'Peace in the body. Peace in the mind. Peace in the spirit. Sleep is pratyahara — the yogi\'s nightly return to source.',
                  meaning:'Taittiriya Upanishad — three repetitions release the three layers of disturbance.' },
      thay:     { cls:'sm-jade', srcCls:'src-thay',  tag:'Sleep gatha · Plum Village',
                  verse:'"Falling into the arms of the Earth, I let go of the day. The Earth holds me. The breath holds me."',
                  meaning:'Thay taught sleep as a form of deep practice — not escape but surrender to what holds you.' },
      buddhist: { cls:'sm-sky',  srcCls:'src-buddhist', tag:'Metta for sleep · loving-kindness',
                  verse:'"May all beings be happy. May all beings be safe. May all beings be well. May all beings be free." — Metta Sutta',
                  meaning:'Ending the day with loving-kindness directed outward is both practice and invitation to rest.' },
      universal:{ cls:'sm-jade', srcCls:'src-both',   tag:'Universal sleep reflection',
                  verse:'"Before sleep: name one thing today that was good. Name one person who showed up for you. Then rest."',
                  meaning:'Research shows a brief gratitude reflection before sleep measurably improves sleep quality.' }
    }
  };

  var shloka = shlokas[slot] && shlokas[slot][trad];
  return shloka || (shlokas[slot] && shlokas[slot].universal) || null;
}

/* Build a shloka-mini HTML string */
function buildShlokaHTML(shloka) {
  if (!shloka) return '';
  var parts = ['<div class="shloka-mini ' + shloka.cls + '">',
    '<span class="shloka-src-tag ' + shloka.srcCls + '">' + (shloka.srcCls.replace('src-','')) + '</span>',
    shloka.tag ? '<div class="shloka-tag">' + shloka.tag + '</div>' : '',
    shloka.deva ? '<div class="shloka-deva">' + shloka.deva + '</div>' : '',
    shloka.verse ? '<div class="shloka-verse">' + shloka.verse + '</div>' : '',
    shloka.meaning ? '<div class="shloka-meaning">' + shloka.meaning + '</div>' : '',
    '</div>'];
  return parts.join('');
}

/* Build pill row HTML */
function buildPillsHTML(pillArray) {
  if (!pillArray || !pillArray.length) return '';
  var items = pillArray.map(function(p) {
    var parts = p.split(':');
    return '<span class="sp ' + parts[0] + '">' + (parts[1] || '') + '</span>';
  }).join('');
  return '<div class="sub-pills">' + items + '</div>';
}

/* Build a single timeline card */
function buildCard(config) {
  var dotClass   = config.dotClass   || 'dot-later';
  var stripClass = config.stripClass || 'strip-later';
  var cardClass  = config.cardClass  || '';
  var badge      = config.badge ? '<span class="badge ' + config.badgeClass + '">' + config.badge + '</span>' : '';
  var shloka     = config.shloka ? buildShlokaHTML(config.shloka) : '';
  var pills      = config.pills  ? buildPillsHTML(config.pills)   : '';

  return [
    '<div class="tl-row">',
      '<div class="tl-left">',
        '<div class="tl-time">' + config.time + '</div>',
        '<div class="tl-dot ' + dotClass + '"></div>',
        dotClass !== 'dot-later' || config.showLine !== false ? '<div class="tl-line"></div>' : '',
      '</div>',
      '<div class="tl-card ' + cardClass + '">',
        '<div class="tl-strip ' + stripClass + '"></div>',
        '<div class="tl-head">',
          '<div><div class="tl-title">' + config.title + '</div>',
          '<div class="tl-sub">' + config.sub + '</div></div>',
          badge,
        '</div>',
        shloka,
        pills,
      '</div>',
    '</div>'
  ].join('');
}

/* Main dinacharya renderer */
function renderDinacharya() {
  var container = document.getElementById('dina-timeline-container');
  if (!container) return;

  var mood   = currentMood || 'balanced';
  var m      = MOOD_DATA[mood] || MOOD_DATA.balanced;
  var combo  = STATE.doshaCombo.length ? STATE.doshaCombo : ['pitta'];

  // Dosha-specific food notes
  var foodNote = getDoshaFoodNote(combo, mood);
  var walkNote = getDoshaWalkNote(combo, mood);

  var cards = [
    buildCard({
      time: '5:00', dotClass:'dot-done', stripClass:'strip-done', cardClass:'card-done',
      title:'✓ Brahma muhurta wake', sub:'Diya alarm · morning prayer · pranayama',
      badge:'Done', badgeClass:'badge-done',
      shloka: getTraditionShloka('wake', mood),
      pills: [['sp-sg:Prayer ✓', 'sp-jade:Morning practice ✓', 'sp-sg:Pranayama ✓']]
    }),
    buildCard({
      time: '5:30', dotClass:'dot-done', stripClass:'strip-done', cardClass:'card-done',
      title:'✓ Walking meditation',
      sub: walkNote || m.walkSub,
      badge:'Done', badgeClass:'badge-done',
      pills: [m.walkPills]
    }),
    buildCard({
      time: '8:00', dotClass:'dot-done', stripClass:'strip-done', cardClass:'card-done',
      title:'✓ Breakfast · food prayer',
      sub: foodNote || m.foodSub,
      badge:'Done', badgeClass:'badge-done',
      shloka: getTraditionShloka('food', mood),
      pills: [m.foodPills]
    }),
    buildCard({
      time: '9:41', dotClass:'dot-now', stripClass:'strip-now', cardClass:'card-now',
      title:'Work sadhana · Now',
      sub:'Hourly bell · nishkama karma · focus block',
      badge:'Now', badgeClass:'badge-now',
      shloka: getTraditionShloka('work', mood),
      pills: [m.workPills]
    }),
    buildCard({
      time: '1:00', dotClass:'dot-soon', stripClass:'strip-soon',
      title:'Lunch · midday prayer',
      sub: m.lunchSub,
      badge:'Upcoming', badgeClass:'badge-soon',
      shloka: getTraditionShloka('food', mood),
      pills: [m.lunchPills]
    }),
    buildCard({
      time: '3:00', dotClass:'dot-soon', stripClass:'strip-soon',
      title: m.afternoonTitle,
      sub: m.afternoonSub,
      shloka: {
        cls:'sm-jade', srcCls:'src-both', tag:'Afternoon · returning home',
        verse: m.afternoonVerse, meaning: m.afternoonMeaning
      }
    }),
    buildCard({
      time: '7:30', dotClass:'dot-later', stripClass:'strip-later',
      title:'Evening sadhana',
      sub:'Meditation · journaling · Begin Anew',
      shloka: getTraditionShloka('evening', mood),
      pills: [['sp-sf:Meditation', 'sp-sf:Journal', 'sp-jade:Begin Anew', 'sp-sg:Abhyanga']]
    }),
    buildCard({
      time: '9:30', dotClass:'dot-later', stripClass:'strip-later',
      title:'Sleep wind-down',
      sub:'Sleep prayer · yoga nidra · screen off by 9 PM',
      shloka: getTraditionShloka('sleep', mood),
      showLine: false
    })
  ];

  // Flatten pills arrays in cards (fix: pills passed as array of arrays)
  container.innerHTML = cards.join('');

  // Update print sub
  var today = new Date().toLocaleDateString('en-IN', { weekday:'long', day:'numeric', month:'long' });
  setText('dina-print-sub', STATE.doshaCombo.map(function(d){return d.charAt(0).toUpperCase()+d.slice(1);}).join('-') + ' · ' + today);
}

/* Dosha-specific food note */
function getDoshaFoodNote(combo, mood) {
  var notes = {
    'vata':       'Vata: warm, oily, grounding foods · avoid cold and raw',
    'pitta':      'Pitta: cooling foods · no spicy, sour or fermented today',
    'kapha':      'Kapha: light, spiced, warm · skip heavy breakfast',
    'vata-pitta': 'Vata-Pitta: warm but not spicy · basmati, cooked veg, mild spices',
    'kapha-pitta':'Pitta-Kapha: light, cool, well-spiced · avoid heavy and spicy',
    'vata-kapha': 'Vata-Kapha: warm, lightly spiced · middle path between V and K',
    'kapha-pitta-vata': 'Tridoshic: season-appropriate · follow mood-based guidance today'
  };
  var key = combo.slice().sort().join('-');
  return notes[key] || '';
}

/* Dosha-specific walk note */
function getDoshaWalkNote(combo, mood) {
  var notes = {
    'vata':       'Slow, warm, grounded walk · avoid cold and wind',
    'pitta':      'Moderate pace · shaded path · early morning or evening',
    'kapha':      'Brisk, vigorous walk · morning sun · push the pace',
    'vata-pitta': 'Moderate pace · some shade · intention-setting before stepping out',
    'kapha-pitta':'Vigorous but not in midday heat · morning is ideal',
    'vata-kapha': 'Brisk enough to energise Kapha, warm enough to ground Vata',
    'kapha-pitta-vata': 'Moderate vigorous walk · listen to which dosha needs more attention today'
  };
  var key = combo.slice().sort().join('-');
  return notes[key] || '';
}

/* Current mood tracking */
var currentMood = 'balanced';

function setMood(mood, el) {
  currentMood = mood;
  document.querySelectorAll('.mchip').forEach(function(c) { c.classList.remove('active'); });
  el.classList.add('active');

  var m = MOOD_DATA[mood];
  var notice = document.getElementById('mood-notice');
  if (notice) {
    if (m && m.notice) { notice.textContent = m.notice; notice.classList.add('visible'); }
    else notice.classList.remove('visible');
  }

  renderDinacharya();
  recordActivity();
}

/* ═══════════════════════════════════════════════════════════
   SECTION 11 · JOURNAL RENDERER (tradition-filtered)
   ═══════════════════════════════════════════════════════════ */
function renderJournal() {
  var trad    = STATE.tradition || 'universal';
  var content = TRADITION_CONTENT[trad] || TRADITION_CONTENT.universal;
  var area    = document.getElementById('journal-prompts-area');
  if (!area) return;

  // Build only this tradition's prompts — no mixing
  var html = content.journalPrompts.map(function(p, i) {
    var savedKey = 'arogya-journal-' + trad + '-' + i;
    var saved = '';
    try { saved = localStorage.getItem(savedKey) || ''; } catch(e) {}

    return [
      '<div class="prompt-card">',
        '<span class="prompt-src ' + p.src + '">' + content.tradLabel + '</span>',
        '<div class="prompt-top">',
          '<span class="prompt-icon">' + p.icon + '</span>',
          '<div class="prompt-q">' + p.q + '</div>',
        '</div>',
        '<div class="prompt-ctx">' + p.ctx + '</div>',
        '<textarea class="prompt-textarea" placeholder="Write freely…"',
          ' data-key="' + savedKey + '"',
          ' oninput="savePrompt(this)">',
          escapeHTML(saved),
        '</textarea>',
      '</div>'
    ].join('');
  }).join('');

  area.innerHTML = html;

  // Load past entries
  renderPastEntries();
}

function savePrompt(ta) {
  var key = ta.dataset.key;
  if (!key) return;
  try { localStorage.setItem(key, ta.value); } catch(e) {}
  recordActivity();
}

function renderPastEntries() {
  var list = document.getElementById('past-entries-list');
  if (!list) return;
  try {
    var entries = JSON.parse(localStorage.getItem('arogya-journal-entries') || '[]');
    if (entries.length === 0) {
      list.innerHTML = '<div class="timeline-loading">No entries yet — write your first today.</div>';
      return;
    }
    list.innerHTML = entries.slice(-3).reverse().map(function(e) {
      return '<div class="entry-card"><div class="entry-date"><div class="entry-dot" style="background:var(--sf)"></div>' + e.date + '</div><div class="entry-preview">' + escapeHTML(e.preview) + '</div></div>';
    }).join('');
  } catch(ex) {}
}

/* ═══════════════════════════════════════════════════════════
   SECTION 12 · PROGRAMME RENDERER (tradition-filtered)
   ═══════════════════════════════════════════════════════════ */
var PROGRAMME_DATA = {
  hindu: {
    intro: [
      '"Yogasthah kuru karmani sangam tyaktva Dhananjaya." — Be steadfast in yoga, perform your duty, abandoning attachment. — Gita 2.48',
      '"Krodhad bhavati sammohah sammohat smritibhramah." — From anger comes delusion; from delusion, loss of memory. — Gita 2.63',
      '"Uddhared atmanatmanam." — Elevate yourself by yourself. Your highest practice is your life lived with awareness. — Gita 6.5'
    ],
    weeks: [
      [ // Week 1
        { theme:'Karagre vasate — consecrate your hands', desc:'Before rising, hold both hands before your eyes. At the fingertips: Lakshmi. At the centre: Saraswati. At the root: Govinda. Look — really look.', dur:'5 min · on waking' },
        { theme:'Pranayama — the breath as bridge', desc:'10 minutes of Nadi Shodhana. Alternate nostrils, 4-4-4-4 count. The breath connects the material and spiritual worlds.', dur:'10 min · morning' },
        { theme:'Ahimsa in thought', desc:'Today, notice every moment you think something unkind about yourself. Do not suppress — just notice. That awareness is the beginning of ahimsa.', dur:'All day awareness' },
        { theme:'Brahmarpanam — eating as yajna', desc:'Recite Brahmarpanam before every meal today. Each meal becomes an offering. Notice what changes.', dur:'3 meals · prayer' },
        { theme:'Karmanye vadhikaraste — work without grasping', desc:'Set a timer. For one full hour, work without checking the outcome. No results, no feedback, no validation. Pure action.', dur:'1 hour practice' },
        { theme:'Sandhyavandana — the twilight prayer', desc:'At sunset, stop whatever you are doing for 5 minutes. Face the setting sun. Recite Asato ma. Let the day go.', dur:'5 min · at sunset' },
        { theme:'Svadhyaya — first week reflection', desc:'Read your journal from this week. What recurring pattern do you see? Write one honest sentence about it.', dur:'Journal · 20 min' }
      ],
      [ // Week 2
        { theme:'Dharma question', desc:'"What is your role in the world right now — not your job, but your dharma? What does life genuinely ask of you?" Write freely.', dur:'Journal · 30 min' },
        { theme:'Nadi Shodhana — balance the pranas', desc:'15 minutes of alternate nostril breathing before work. Note which nostril flows more freely. That is which hemisphere is dominant today.', dur:'15 min · morning' },
        { theme:'Anger and the Gita', desc:'"From anger comes delusion." Today, when you feel irritation arising — pause and trace it. What need is underneath the anger?', dur:'All day awareness' },
        { theme:'Seva — selfless action', desc:'One act of giving today with no expectation of acknowledgment. Offer it and release it completely.', dur:'One act' },
        { theme:'Tapas — disciplined practice', desc:'Do something difficult today for its own sake. Not for results. The difficulty IS the practice.', dur:'Choose your challenge' },
        { theme:'Pratyahara — withdrawal of the senses', desc:'No screens for 2 hours before bed for the rest of the programme. This is pratyahara — turning the senses inward.', dur:'Every evening' },
        { theme:'Week 2 reflection', desc:'"What did I resist this week? What did that resistance protect? What would it mean to no longer need that protection?"', dur:'Journal · 20 min' }
      ],
      [ // Week 3
        { theme:'Nishkama karma in your daily work', desc:'This entire day: take no action motivated by fear of judgment. Every action must come from genuine care or clear duty.', dur:'Full day practice' },
        { theme:'Brahmacharya — energy conservation', desc:'Today, notice where you leak energy: unnecessary speech, distracted scrolling, emotional reactivity. Simply notice. Conservation begins with awareness.', dur:'All day' },
        { theme:'Guru within', desc:'Sit quietly for 20 minutes. Ask the question: "What do I already know — that I am not yet living?" Write what comes.', dur:'20 min meditation' },
        { theme:'Compassion as practice', desc:'"Sarve bhavantu sukhinah — may all beings be happy." Say this for five people today: one you love, one you are neutral about, one who has hurt you.', dur:'5 people · all day' },
        { theme:'Gita chapter 2 — the whole teaching', desc:'Read Bhagavad Gita Chapter 2 slowly. One verse at a time. Stop when something lands. Stay with that verse for the day.', dur:'Study practice' },
        { theme:'Jivatma and Paramatma', desc:'Meditate on the question: "Who is aware of my thoughts?" Not your thoughts — the awareness behind them. Rest in that awareness.', dur:'20 min meditation' },
        { theme:'Day 21 — ceremony of completion', desc:'Write your Day 1 answers again from memory. Compare. Write one sentence about what has genuinely shifted. Set your sankalpa for the next cycle.', dur:'30 min ceremony' }
      ]
    ]
  },
  thay: {
    intro: [
      '"The present moment is the only moment available to us, and it is the door to all moments." — Thich Nhat Hanh',
      '"Breathing in, I am aware of my feeling. Breathing out, I smile at my feeling." — Plum Village',
      '"Make your life your message." — Thich Nhat Hanh'
    ],
    weeks: [
      [
        { theme:'Waking up, I smile', desc:'Before rising: "Waking up this morning, I smile. Twenty-four brand new hours are before me." Recite it slowly. Let the smile precede the day.', dur:'5 min · on waking' },
        { theme:'Mindful walking — I have arrived', desc:'Walk for 15 minutes outdoors with no destination. With each step: "I have arrived. I am home." Two steps inhale, two steps exhale.', dur:'15 min walk' },
        { theme:'Mindful breathing — in and out', desc:'10 minutes: breathe in and say "in", breathe out and say "out". That is all. No added meaning. No goal. Just in. Just out.', dur:'10 min · morning' },
        { theme:'Eating with gratitude', desc:'At one meal today: put down all devices. Recite the Five Contemplations. Chew slowly. Count 20 chews per bite. Notice one new taste.', dur:'One meal' },
        { theme:'The bell of mindfulness', desc:'Every time you hear a notification today — pause. Three breaths. "I am here. I am home." Use technology\'s interruptions as bells.', dur:'All day' },
        { theme:'Deep listening practice', desc:'In your next conversation: listen for two full minutes without planning your response. Simply receive what is being offered.', dur:'One conversation' },
        { theme:'Week 1 reflection', desc:'"What did I notice this week that I had never noticed before?" Write freely. No editing.', dur:'Journal · 20 min' }
      ],
      [
        { theme:'Interbeing — look at your hand', desc:'Hold your hand in front of you. Name five things that are "not-you" present in it right now. Let this understanding change how you see yourself.', dur:'10 min contemplation' },
        { theme:'Watering flowers — not weeds', desc:'Today, find one quality to appreciate sincerely in three people around you. Tell them. This is "flower watering" — the first step of Begin Anew.', dur:'3 people · all day' },
        { theme:'Walking meditation outdoors', desc:'20 minutes of mindful walking. Kiss the Earth with your feet. "Peace is every step." Slow down until you feel your feet fully meet the ground.', dur:'20 min walk' },
        { theme:'Begin Anew ceremony', desc:'Alone or with someone you trust: 1) Express appreciation. 2) Express a regret. 3) Share what hurt you. 4) Ask for what you need. Be honest. Be kind.', dur:'Evening practice' },
        { theme:'Mindful consumption — the fifth training', desc:'Before every digital scroll today: pause and ask "Need or escape?" Make the choice consciously. Notice the difference in how you feel afterward.', dur:'All day' },
        { theme:'Compassion for one difficult person', desc:'Bring to mind someone who has hurt you. Say silently: "Like me, this person suffers. Like me, this person wants to be free." Repeat for 5 minutes.', dur:'5 min meditation' },
        { theme:'Week 2 reflection', desc:'"Where did I resist coming home to the present moment this week? What was I avoiding?" Write without judgment.', dur:'Journal · 20 min' }
      ],
      [
        { theme:'No mud, no lotus', desc:'"The lotus grows from mud. Without suffering, there can be no happiness." Sit with a difficulty in your life. How is it also compost for something new?', dur:'20 min contemplation' },
        { theme:'Breathing into the community', desc:'Join a live group session in Ārogya Circles. Practise in silence alongside others. Feel the collective field. Notice what shifts.', dur:'Group practice' },
        { theme:'Mindful speech for one day', desc:'Today: speak only what is true, necessary, and kind. Before speaking, ask: "Is it true? Is it kind? Is it necessary?" Practice all three.', dur:'All day' },
        { theme:'Nature as sangha', desc:'30 minutes outdoors with no purpose. Look at one leaf, one cloud, one bird. Let it teach you what you cannot learn from a screen.', dur:'30 min' },
        { theme:'No birth, no death', desc:'"The cloud never dies — it becomes rain." Sit with someone or something you have lost. Can you find where they have gone — not disappeared, but transformed?', dur:'Contemplation' },
        { theme:'The river of perception', desc:'"We are prisoners of our perceptions." Today, take one fixed view you hold about someone, and genuinely try on the opposite view for 10 minutes.', dur:'10 min practice' },
        { theme:'Day 21 — life as message', desc:'"Make your life your message." Write one sentence that you want your life to say — not to others, but to yourself. Then write what your life is actually saying today. Begin Anew.', dur:'30 min ceremony' }
      ]
    ]
  },
  buddhist: {
    intro: [
      '"Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment." — Buddha',
      '"In the end, only three things matter: how much you loved, how gently you lived, and how gracefully you let go." — Buddhist teaching',
      '"Peace comes from within. Do not seek it without." — Buddha'
    ],
    weeks: [
      [
        { theme:'Metta for yourself', desc:'"May I be happy. May I be well. May I be safe. May I be peaceful." Say this slowly, as if for the first time. Mean every word.', dur:'10 min · morning' },
        { theme:'Anapanasati — breath awareness', desc:'20 minutes: simply watch the breath enter and leave. When the mind wanders, return without judgment. Each return IS the practice.', dur:'20 min meditation' },
        { theme:'Noble silence', desc:'One hour of genuine silence today. No phone, no background audio, no unnecessary speech. Just notice what the silence reveals.', dur:'1 hour' },
        { theme:'Impermanence — Anicca', desc:'Hold something you cherish. Notice it is already changing. Already, in some sense, gone. Let that awareness add depth, not sadness, to the holding.', dur:'10 min contemplation' },
        { theme:'Mindful eating — Sati with food', desc:'One meal today: no conversation, no screen, no reading. Pure eating. Taste each bite as if tasting food for the first time.', dur:'One meal' },
        { theme:'Tonglen — taking and sending', desc:'Breathe in suffering — your own or another\'s. Breathe out relief, space, compassion. You are not absorbing it; you are transforming it.', dur:'10 min · evening' },
        { theme:'Week 1 reflection — Svadhyaya', desc:'"What arose this week that I did not expect? What does that tell me about what I was expecting?"', dur:'Journal · 20 min' }
      ],
      [
        { theme:'The Noble Eightfold Path — Right View', desc:'Spend today noticing how you see things. Not what you see — how. Notice one assumption you are making that may not be true.', dur:'All day' },
        { theme:'Vipassana — insight practice', desc:'30 minutes: sit quietly. Watch thoughts arise and pass like clouds. Note them: "thinking… planning… remembering…" without following them.', dur:'30 min meditation' },
        { theme:'Right speech — loving words', desc:'Today: speak no harsh words. If anger arises, wait until it passes before speaking. Notice the gap between impulse and action.', dur:'All day' },
        { theme:'Metta for a difficult person', desc:'"Like me, this person wants to be happy. Like me, this person suffers. May they be free from suffering." Sit with this for 10 minutes.', dur:'10 min meditation' },
        { theme:'Right livelihood inquiry', desc:'"Does the way I earn and spend my resources cause harm — to others, to the Earth, to my own spirit?" Write honestly.', dur:'Journal · 20 min' },
        { theme:'Sangha — the third jewel', desc:'"I take refuge in the Sangha." Connect with one person on your spiritual path today. Not to talk — to practice together in silence.', dur:'Group practice' },
        { theme:'Week 2 reflection', desc:'"Where did I cause harm this week — in thought, speech, or action? What would I do differently?"', dur:'Journal · 20 min' }
      ],
      [
        { theme:'Bodhicitta — the awakening mind', desc:'What if your practice were not for yourself alone, but for the liberation of all beings? How would that change how you sat this morning?', dur:'20 min meditation' },
        { theme:'Dukkha — looking at suffering', desc:'"Life contains dukkha." Sit with one source of suffering in your life without trying to fix it. Simply be with it. Notice what happens when you stop fighting.', dur:'15 min contemplation' },
        { theme:'Right effort all day', desc:'Prevent unwholesome states before they arise. Abandon those that have arisen. Cultivate wholesome states. Sustain what is already good.', dur:'All day' },
        { theme:'Dependent origination', desc:'"This is, because that is." Trace one current difficulty back through its conditions. How many links in the chain? Can you see the first cause?', dur:'Contemplation' },
        { theme:'Metta for all beings', desc:'Expand the circle: yourself → loved ones → neutral people → difficult people → all beings in all directions. Let the love become genuinely boundless.', dur:'20 min meditation' },
        { theme:'Sila — ethical conduct review', desc:'Review the Five Precepts: non-harming, not-taking, right speech, wise conduct, clarity of mind. Where are you strong? Where is the growing edge?', dur:'Journal · 20 min' },
        { theme:'Day 21 — dedication of merit', desc:'"By this practice, may all beings be free from suffering. May all beings know peace." Write one vow for how your practice will serve the world going forward.', dur:'30 min ceremony' }
      ]
    ]
  },
  universal: {
    intro: [
      '"The present moment is the only home we ever have. All of science, all of philosophy, and all of wisdom traditions agree on this one thing." — Universal teaching',
      '"You are not a human having a spiritual experience. You are a spiritual being having a human experience." — Pierre Teilhard de Chardin',
      '"Your task is not to seek for love, but merely to seek and find all the barriers within yourself that you have built against it." — Rumi'
    ],
    weeks: [
      [
        { theme:'Three conscious breaths', desc:'Before anything else today: three breaths, fully felt. That is the complete morning practice. Everything else grows from this.', dur:'3 breaths · on waking' },
        { theme:'Body scan', desc:'Lie down for 10 minutes. Move your attention slowly from feet to crown. Not to fix anything — just to notice what is there.', dur:'10 min · morning' },
        { theme:'Phone-free morning', desc:'From waking until after breakfast: no phone. Notice what arises in the space. Notice what you reach for the phone to escape.', dur:'Until breakfast' },
        { theme:'Gratitude — specific and embodied', desc:'Three specific gratitudes before opening any app. Not vague ones. Name the exact moment, the exact person, the exact feeling.', dur:'5 min · morning' },
        { theme:'Single-tasking experiment', desc:'For one hour: one task, one window, one focus. Close everything else. Notice the quality of your attention at the end of the hour.', dur:'1 hour' },
        { theme:'Nature time', desc:'20 minutes outdoors with no device and no purpose. Let your attention be led by what moves — a leaf, a bird, the quality of the light.', dur:'20 min outdoors' },
        { theme:'Week 1 reflection', desc:'"What surprised me about my own mind this week? What did I notice that I have been ignoring?"', dur:'Journal · 20 min' }
      ],
      [
        { theme:'Emotional vocabulary', desc:'Check in right now: what is the most precise word for what you are feeling? Not "fine" or "good". Use this vocabulary wheel: anxious / braced / hollow / foggy / tender / contracted / expanded / grounded.', dur:'Daily check-in' },
        { theme:'The 90-second rule', desc:'Neuroscientist Jill Bolte Taylor found emotions peak in 90 seconds if you don\'t feed them with thought. Today: let one emotion complete its 90-second arc without resisting or indulging it.', dur:'Practice when needed' },
        { theme:'Deep listening', desc:'In your next important conversation: listen for 2 full minutes without planning your reply. Simply receive. Notice what you hear that you normally miss.', dur:'One conversation' },
        { theme:'Compassion for difficulty', desc:'Bring to mind someone you find difficult. Spend 5 minutes genuinely wishing them well — not as performance, but as practice. Notice what shifts.', dur:'5 min meditation' },
        { theme:'Values audit', desc:'Write your top 5 values. Then write how you actually spent your time this week. Compare honestly. Where is the gap?', dur:'Journal · 20 min' },
        { theme:'Digital fasting', desc:'One full evening without screens. No exception. Notice the restlessness. Notice what it transforms into after 30 minutes.', dur:'One evening' },
        { theme:'Week 2 reflection', desc:'"Where am I most defended right now? What am I protecting? Is it still worth protecting?"', dur:'Journal · 20 min' }
      ],
      [
        { theme:'Purpose question', desc:'"What would you do if you knew you could not fail?" is the wrong question. The right one: "What would you do even knowing you might fail?"', dur:'Journal · 30 min' },
        { theme:'Connection practice', desc:'Reach out to one person you have been meaning to contact. Not with a reason. Just to say: you thought of them. Notice your resistance and do it anyway.', dur:'One message or call' },
        { theme:'The witness practice', desc:'Sit quietly for 20 minutes. Notice thoughts arise. Ask: "Who is aware of this thought?" Rest in the awareness, not the thought.', dur:'20 min meditation' },
        { theme:'Acts of kindness — anonymously', desc:'Three acts of kindness today that no one will trace back to you. No credit. Pure giving. Notice how this feels different from acknowledged generosity.', dur:'Three acts' },
        { theme:'Letter to future self', desc:'Write a letter to yourself to be opened in one year. Tell them what you are learning, what you are afraid of, and what you are becoming.', dur:'Journal · 30 min' },
        { theme:'Your life as message', desc:'"What message is your life sending right now — to those watching you live it?" Write the message you intend. Then write the one you are actually sending.', dur:'Journal · 30 min' },
        { theme:'Day 21 — completion', desc:'Read your Day 1 journal entry. Write a response to who you were then. Set one clear intention for how you will live differently in the next cycle.', dur:'30 min ceremony' }
      ]
    ]
  }
};

function renderProgramme() {
  var trad   = STATE.tradition || 'universal';
  var data   = PROGRAMME_DATA[trad] || PROGRAMME_DATA.universal;
  var panels = document.getElementById('week-panels');
  if (!panels) return;

  var today  = STATE.progDay || 0;
  setText('prog-sub', (TRADITION_CONTENT[trad] || TRADITION_CONTENT.universal).tradLabel + ' · 21-day journey');

  var html = data.weeks.map(function(week, wi) {
    var intro = data.intro[wi] || '';
    var days  = week.map(function(day, di) {
      var dayNum    = wi * 7 + di + 1;
      var isDone    = dayNum < today;
      var isToday   = dayNum === today;
      var isLocked  = dayNum > today;
      var cardClass = isDone ? 'card-done' : isToday ? 'card-today' : '';
      var status    = isDone ? '<span class="day-status status-done">✓ Done</span>'
                    : isToday ? '<span class="day-status status-today">Today</span>'
                    : '<span class="day-status status-locked">Locked</span>';
      var onclick   = isToday ? 'onclick="completeDay(' + dayNum + ')"' : '';
      return [
        '<div class="day-card ' + cardClass + '" ' + onclick + '>',
          '<div class="day-num">' + dayNum + '</div>',
          '<div class="day-info">',
            '<div class="day-theme">' + day.theme + '</div>',
            '<div class="day-desc">' + day.desc + '</div>',
            '<div class="day-duration">' + day.dur + '</div>',
          '</div>',
          status,
        '</div>'
      ].join('');
    }).join('');

    var visible = wi === 0 ? 'visible' : '';
    return [
      '<div class="week-panel ' + visible + '" id="wp' + (wi+1) + '">',
        '<div class="week-intro">' + intro + '</div>',
        days,
      '</div>'
    ].join('');
  }).join('');

  panels.innerHTML = html;
}

function completeDay(dayNum) {
  if (dayNum !== STATE.progDay) return;
  STATE.progDay = dayNum + 1;
  saveState();
  recordActivity();
  renderProgramme();
  updateStats();
}

function showWeek(w, el) {
  document.querySelectorAll('.wtab').forEach(function(t) { t.classList.remove('active'); });
  el.classList.add('active');
  document.querySelectorAll('.week-panel').forEach(function(p) { p.classList.remove('visible'); });
  var panel = document.getElementById('wp' + w);
  if (panel) panel.classList.add('visible');
}

/* ═══════════════════════════════════════════════════════════
   SECTION 13 · BREATHWORK ENGINE
   ═══════════════════════════════════════════════════════════ */
var BREATH_DATA = {
  nadi:     { in:4, hold:4, out:4, hold2:0, cycles:6, name:'Nadi Shodhana',
    instr:'Alternate nostril breathing. Right thumb closes right nostril — inhale left. Then close left, exhale right. Continue alternating.',
    benefit:'🌿 Nadi Shodhana — balances both brain hemispheres. Reduces cortisol within 5 minutes. Especially effective for Pitta and Vata-Pitta types. Evidence: reduces systolic blood pressure, improves heart rate variability.' },
  bhramari: { in:4, hold:0, out:8, hold2:0, cycles:8, name:'Bhramari',
    instr:'Humming bee breath. Close ears with thumbs, eyes with fingers. Inhale fully. Exhale with a sustained hum — feel the vibration in the skull.',
    benefit:'🐝 Bhramari — activates the vagus nerve through vibration. Reduces anxiety, hypertension, and racing thoughts. Most effective for Vata imbalance.' },
  box:      { in:4, hold:4, out:4, hold2:4, cycles:6, name:'Box breathing',
    instr:'Inhale 4 counts. Hold 4. Exhale 4. Hold empty 4. Used by athletes and Navy SEALs to manage extreme stress and sustain peak focus.',
    benefit:'📦 Box breathing — activates prefrontal cortex. Reduces cortisol. Improves executive function. 4 minutes before any difficult task.' },
  '478':    { in:4, hold:7, out:8, hold2:0, cycles:4, name:'4-7-8 Sleep breath',
    instr:'Inhale through nose 4 counts. Hold 7 counts. Exhale through mouth with whoosh 8 counts. Practice only in bed before sleep.',
    benefit:'🌙 4-7-8 — extended exhalation activates parasympathetic system. Reduces time to sleep onset significantly.' },
  thay:     { in:4, hold:0, out:4, hold2:0, cycles:8, name:"Thay's breath",
    instr:'"Breathing in, I calm my body. Breathing out, I smile." Recite silently with each breath. The smile is an invitation, not performance.',
    benefit:"🌸 Thich Nhat Hanh's foundation practice. Every breath a return home. The simplest instruction. The most complete." }
};

var brRunning=false, brInterval=null, brPhaseIndex=0, brCycleCount=0;
var brRemaining=0, brCurrentData=null, brPhases=[];

function setBrType(type, el) {
  document.querySelectorAll('.btab').forEach(function(t){ t.classList.remove('active'); });
  el.classList.add('active');
  brCurrentData = BREATH_DATA[type];
  if (!brCurrentData) return;
  if (brRunning) { clearInterval(brInterval); brRunning=false; }
  brPhaseIndex=0; brCycleCount=0;
  var d = brCurrentData;
  setText('bp-in',   d.in);
  setText('bp-hold', d.hold || '—');
  setText('bp-out',  d.out);
  setText('brCount', d.in);
  setText('brAction','INHALE');
  setText('brCycles','Cycle 1 of '+d.cycles);
  setText('brInstr', d.instr);
  var bDiv = document.getElementById('brBenefit');
  if (bDiv) bDiv.innerHTML = '<div class="br-benefit-title">' + d.benefit.split('\n')[0] + '</div>' + d.benefit.split('\n').slice(1).join(' ');
  var btn = document.getElementById('brBtn');
  if (btn) btn.textContent = 'Begin practice';
  resetBrRing(0);
}

function toggleBreath() {
  if (!brCurrentData) brCurrentData = BREATH_DATA.nadi;
  if (brRunning) {
    clearInterval(brInterval); brRunning=false;
    var btn = document.getElementById('brBtn');
    if (btn) btn.textContent = 'Continue';
    return;
  }
  brRunning=true;
  var btn = document.getElementById('brBtn');
  if (btn) btn.textContent = 'Pause';
  var d = brCurrentData;
  brPhases = [
    { label:'INHALE', secs:d.in,    colour:'var(--sf)' }
  ];
  if (d.hold)  brPhases.push({ label:'HOLD',   secs:d.hold,  colour:'var(--gd)' });
  brPhases.push({ label:'EXHALE', secs:d.out,   colour:'var(--sky)' });
  if (d.hold2) brPhases.push({ label:'HOLD',   secs:d.hold2, colour:'var(--gd)' });

  brPhaseIndex=0; brRemaining=brPhases[0].secs;
  brInterval = setInterval(function() {
    var phase = brPhases[brPhaseIndex];
    setText('brAction', phase.label);
    setText('brCount',  brRemaining);
    setText('brCycles', 'Cycle '+(brCycleCount+1)+' of '+brCurrentData.cycles);
    var ring = document.getElementById('brRing');
    if (ring) {
      ring.style.stroke = phase.colour;
      ring.style.strokeDashoffset = 565*(1-(1-brRemaining/phase.secs));
      ring.style.transition = 'stroke-dashoffset 1s linear';
    }
    brRemaining--;
    if (brRemaining < 0) {
      brPhaseIndex++;
      if (brPhaseIndex >= brPhases.length) { brPhaseIndex=0; brCycleCount++; }
      if (brCycleCount >= brCurrentData.cycles) {
        clearInterval(brInterval); brRunning=false;
        setText('brAction','COMPLETE'); setText('brCount','✦');
        var b = document.getElementById('brBtn');
        if (b) b.textContent='Practice complete ✦';
        resetBrRing(1);
        return;
      }
      brRemaining = brPhases[brPhaseIndex].secs;
    }
  }, 1000);
}

function resetBrRing(full) {
  var ring = document.getElementById('brRing');
  if (ring) { ring.style.transition='none'; ring.style.strokeDashoffset = full ? '0' : '565'; }
}

/* ═══════════════════════════════════════════════════════════
   SECTION 14 · WELLNESS TRACKER
   ═══════════════════════════════════════════════════════════ */
var lowMoodStreak = 0;

function updateSlider(input) {
  var val = input.nextElementSibling;
  if (val) val.textContent = input.value;
}

function checkSafety(value) {
  if (parseInt(value) <= 3) lowMoodStreak++;
  else lowMoodStreak = 0;
  if (lowMoodStreak >= 3) {
    var banner = document.getElementById('safetyBanner');
    if (banner) banner.classList.add('visible');
  }
}

/* Save check-in */
function saveCheckin() {
  var sliders = document.querySelectorAll('.ci-slider');
  var labels  = ['sleep','energy','mood','digestion','stress'];
  var data    = { date: todayStr() };
  sliders.forEach(function(s, i) { data[labels[i]] = parseInt(s.value); });
  try {
    var all = JSON.parse(localStorage.getItem('arogya-checkins') || '[]');
    all.push(data);
    if (all.length > 90) all = all.slice(-90);
    localStorage.setItem('arogya-checkins', JSON.stringify(all));
  } catch(e) {}
  recordActivity();
}

/* ═══════════════════════════════════════════════════════════
   SECTION 15 · FOCUS TIMER
   ═══════════════════════════════════════════════════════════ */
var timerTotal=25*60, timerRemain=25*60, timerRunning=false;
var timerInterval=null, timerSession=1, timerBreak=false;

function getSelectedDuration() {
  var chip = document.querySelector('.dur-chip.active');
  return chip ? parseInt(chip.textContent)*60 : 25*60;
}

function updateTimerDisplay() {
  var m=Math.floor(timerRemain/60), s=timerRemain%60;
  setText('tDisp', String(m).padStart(2,'0')+':'+String(s).padStart(2,'0'));
}

function updateTimerRing(progress) {
  var ring = document.getElementById('tRing');
  if (!ring) return;
  ring.style.strokeDashoffset = 540*(1-progress);
  ring.style.stroke = timerBreak ? 'var(--gd)' : 'var(--sf)';
}

function timerTick() {
  if (timerRemain <= 0) {
    clearInterval(timerInterval); timerRunning=false;
    if (!timerBreak) {
      // Session complete — play sound
      playBell(STATE.sessionSound);
      timerBreak=true; timerTotal=5*60; timerRemain=timerTotal;
      setText('tPh','REST');
      var btn=document.getElementById('tPlay');
      if(btn){btn.textContent='▶';btn.classList.remove('paused');}
      STATE.sessionsTotal++; updateStats(); saveState();
    } else {
      timerBreak=false; timerSession++;
      timerTotal=getSelectedDuration(); timerRemain=timerTotal;
      setText('tPh','FOCUS');
      setText('tSs','Session '+timerSession+' of 4');
      var btn=document.getElementById('tPlay');
      if(btn){btn.textContent='▶';btn.classList.remove('paused');}
    }
    updateTimerDisplay(); updateTimerRing(1); return;
  }
  timerRemain--; updateTimerDisplay(); updateTimerRing(timerRemain/timerTotal);
}

function setDuration(mins, el) {
  if (timerRunning) return;
  document.querySelectorAll('.dur-chip').forEach(function(c){c.classList.remove('active');});
  el.classList.add('active');
  timerTotal=mins*60; timerRemain=timerTotal; timerBreak=false;
  updateTimerDisplay(); updateTimerRing(1);
}

function toggleTimer() {
  var btn = document.getElementById('tPlay');
  if (timerRunning) {
    clearInterval(timerInterval); timerRunning=false;
    if(btn){btn.textContent='▶';btn.classList.remove('paused');}
  } else {
    timerInterval=setInterval(timerTick,1000); timerRunning=true;
    if(btn){btn.textContent='⏸';btn.classList.add('paused');}
    recordActivity();
  }
}

function resetTimer() {
  clearInterval(timerInterval); timerRunning=false; timerBreak=false;
  timerSession=1; timerTotal=getSelectedDuration(); timerRemain=timerTotal;
  var btn=document.getElementById('tPlay');
  if(btn){btn.textContent='▶';btn.classList.remove('paused');}
  setText('tPh','FOCUS'); setText('tSs','Session 1 of 4');
  updateTimerDisplay(); updateTimerRing(1);
}

function skipSession() { timerRemain=1; }

function selectSound(sound, el) {
  STATE.sessionSound=sound;
  document.querySelectorAll('.sound-chip').forEach(function(c){c.classList.remove('active');});
  el.classList.add('active');
  saveState();
}

/* ═══════════════════════════════════════════════════════════
   SECTION 16 · JOURNAL UI (mood wheel)
   ═══════════════════════════════════════════════════════════ */
function selectMood(el) {
  document.querySelectorAll('.mood-btn').forEach(function(b){b.classList.remove('active');});
  el.classList.add('active');
}

/* ═══════════════════════════════════════════════════════════
   SECTION 17 · PRINT
   ═══════════════════════════════════════════════════════════ */
function printScreen(screenId) {
  document.querySelectorAll('.screen').forEach(function(s){s.classList.remove('print-target');});
  var target = document.getElementById('screen-'+screenId);
  if (target) target.classList.add('print-target');
  window.print();
}

/* ═══════════════════════════════════════════════════════════
   SECTION 18 · UTILITIES
   ═══════════════════════════════════════════════════════════ */
function setText(id, val) {
  var el = document.getElementById(id);
  if (el) el.textContent = val;
}

function setStyle(id, prop, val) {
  var el = document.getElementById(id);
  if (el) el.style[prop] = val;
}

function escapeHTML(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function updateClock() {
  var now=new Date(), h=now.getHours(), m=now.getMinutes();
  var ampm=h>=12?'PM':'AM';
  h=h%12||12;
  setText('statusTime', h+':'+String(m).padStart(2,'0')+' '+ampm);
}

function checkOffline() {
  setText('connStatus', navigator.onLine ? '▲ ◆◆◆' : '📵 Offline');
}

/* ═══════════════════════════════════════════════════════════
   SECTION 19 · INIT
   ═══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', function() {

  var returning = loadState();

  if (!returning || !STATE.onboardDone) {
    // Reset streak to zero for new/returning without completed onboard
    STATE.streak = 0;
    STATE.todayDone = 0;
    STATE.bellsHeard = 0;
    STATE.sessionsTotal = 0;
    STATE.progDay = 1;
    saveState();
    setTimeout(function() {
      var ov = document.getElementById('onboard');
      if (ov) ov.classList.add('visible');
    }, 600);
  } else {
    // Check if missed days — streak integrity
    if (STATE.lastActiveDate && STATE.lastActiveDate !== todayStr() && STATE.lastActiveDate !== yesterdayStr()) {
      // Missed at least one day — streak resets on next activity
      // (it will reset in recordActivity when they next complete something)
    }
    applyProfileToApp();
  }

  // Init timer
  updateTimerDisplay();
  updateTimerRing(1);

  // Init breathwork (first tab)
  brCurrentData = BREATH_DATA.nadi;
  var firstBtab = document.querySelector('.btab');
  if (firstBtab) setBrType('nadi', firstBtab);

  // Clock
  updateClock();
  setInterval(updateClock, 30000);

  // Offline
  checkOffline();
  window.addEventListener('online',  checkOffline);
  window.addEventListener('offline', checkOffline);

  // Hourly bell scheduler
  scheduleHourlyBell();

  // Sound unlock notice
  if (!STATE.soundUnlocked) showSoundNotice();
  else hideSoundNotice();

  // Start on home
  go('home');

  // Restore dinacharya container placeholder if needed
  var dinaCont = document.getElementById('dina-timeline-container');
  if (dinaCont && !dinaCont.innerHTML.trim()) {
    dinaCont.innerHTML = '<div class="timeline-loading">Complete onboarding to see your personalised dinacharya.</div>';
  }

});


/* ── SCHEDULE MODULE ── */
/* ═══════════════════════════════════════════════════════════════
   ĀROGYA · dina-schedule.js
   Dinacharya Custom Schedule Module — Production v1

   ARCHITECTURE
   ────────────
   STATE.schedule   — array of user-created activity objects
   STATE.smartPrefs — user-edited smart defaults (wake/sleep/detox)
   ACTIVITY_TYPES   — master catalogue of activity definitions
   ACTIVITY_CONTENT — tradition × activity spiritual content library
   Reminder Engine  — setInterval polling, Notification API, toast fallback
   Render Engine    — day-visual bar, sorted card list, smart defaults strip

   HOW TO UPDATE CONTENT
   ─────────────────────
   · Add a new activity type → add entry to ACTIVITY_TYPES
   · Add tradition content   → add entry in ACTIVITY_CONTENT[tradition][activityKey]
   · Change smart defaults   → edit SMART_DEFAULTS_BY_DOSHA
   ═══════════════════════════════════════════════════════════════ */

'use strict';

/* ─────────────────────────────────────────────────────────────
   MODULE 1 · ACTIVITY TYPE CATALOGUE
   Each entry defines an activity's display, colour, and dosha
   relevance so the system can surface it as a suggestion.
   ───────────────────────────────────────────────────────────── */
var ACTIVITY_TYPES = {
  wake: {
    label:'Wake up',       icon:'🌅', colour:'#C9920A', bg:'#FBF5DC',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:15,    category:'routine'
  },
  meditation: {
    label:'Meditation',    icon:'🧘', colour:'#E8651A', bg:'#FDF0E8',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:20,    category:'spiritual'
  },
  pranayama: {
    label:'Pranayama',     icon:'🌬', colour:'#5B8DB8', bg:'#E8F3FA',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:15,    category:'spiritual'
  },
  yoga: {
    label:'Yoga / Exercise',icon:'🤸',colour:'#3D7054', bg:'#EAF3EC',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:45,    category:'body'
  },
  walk: {
    label:'Walking',       icon:'🚶', colour:'#2E8B6A', bg:'#E2F4EE',
    doshaRelevant:['kapha','vata'],
    defaultDuration:30,    category:'body'
  },
  breakfast: {
    label:'Breakfast',     icon:'🍽', colour:'#C9920A', bg:'#FBF5DC',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:30,    category:'food'
  },
  lunch: {
    label:'Lunch',         icon:'🌞', colour:'#E8651A', bg:'#FDF0E8',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:45,    category:'food'
  },
  dinner: {
    label:'Dinner',        icon:'🌙', colour:'#9B5E2A', bg:'#FAF6EF',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:45,    category:'food'
  },
  work: {
    label:'Work / Study',  icon:'💻', colour:'#5B8DB8', bg:'#E8F3FA',
    doshaRelevant:['pitta'],
    defaultDuration:120,   category:'work'
  },
  reading: {
    label:'Reading',       icon:'📖', colour:'#6B3A1F', bg:'#FDF6EF',
    doshaRelevant:['vata','pitta'],
    defaultDuration:30,    category:'learning'
  },
  journaling: {
    label:'Journaling',    icon:'📿', colour:'#9B4F6E', bg:'#F8EDF3',
    doshaRelevant:['vata','pitta'],
    defaultDuration:20,    category:'spiritual'
  },
  abhyanga: {
    label:'Abhyanga / Self-care',icon:'🛁',colour:'#C8956A',bg:'#FDF0E8',
    doshaRelevant:['vata'],
    defaultDuration:20,    category:'body'
  },
  sleep: {
    label:'Sleep',         icon:'🌙', colour:'#1A0A04', bg:'#EAF3EC',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:480,   category:'routine'
  },
  detox: {
    label:'Digital detox', icon:'📵', colour:'#3D7054', bg:'#EAF3EC',
    doshaRelevant:['pitta','kapha'],
    defaultDuration:60,    category:'routine'
  },
  custom: {
    label:'Custom',        icon:'✦',  colour:'#C9920A', bg:'#FBF5DC',
    doshaRelevant:['vata','pitta','kapha'],
    defaultDuration:30,    category:'custom'
  }
};

/* ─────────────────────────────────────────────────────────────
   MODULE 2 · SMART DEFAULTS BY DOSHA
   System-suggested wake / sleep / detox times.
   Users see these as editable chips in the Suggested panel.
   Add new dosha combos by extending this object.
   ───────────────────────────────────────────────────────────── */
var SMART_DEFAULTS_BY_DOSHA = {
  /* Single doshas */
  'vata': {
    wake:  '05:30', sleep: '21:30', detox: '20:30',
    wakeNote:  'Vata benefits from rising at Brahma Muhurta (before 6 AM) — consistency is your medicine',
    sleepNote: 'Vata must sleep early. 9:30 PM protects Vata from night-time overstimulation',
    detoxNote: 'Screens after 8 PM aggravate Vata anxiety — protect the evening quiet'
  },
  'pitta': {
    wake:  '05:30', sleep: '22:00', detox: '21:00',
    wakeNote:  'Pitta benefits from the cooling stillness of early morning before the fire rises',
    sleepNote: 'Pitta is prone to overwork — 10 PM is the boundary that protects your rest',
    detoxNote: 'Blue light and stimulating content after 9 PM aggravate Pitta fire — step away'
  },
  'kapha': {
    wake:  '05:00', sleep: '22:00', detox: '21:00',
    wakeNote:  'Kapha must rise before 6 AM — sleeping past 6 AM increases heaviness and lethargy all day',
    sleepNote: 'Kapha is prone to excess sleep — 10 PM is enough; never sleep past 6 AM',
    detoxNote: 'Kapha' inertia is worsened by passive screen time — an active detox after 9 PM is essential'
  },
  /* Dual doshas */
  'vata-pitta': {
    wake:  '05:30', sleep: '21:45', detox: '20:45',
    wakeNote:  'Vata-Pitta: consistency (for Vata) + the cool of early morning (for Pitta)',
    sleepNote: 'Early enough for Vata stability, firm enough for Pitta overwork patterns',
    detoxNote: 'Both doshas worsen with evening screens — protect this boundary firmly'
  },
  'kapha-pitta': {
    wake:  '05:00', sleep: '22:00', detox: '21:00',
    wakeNote:  'Kapha needs vigorous early morning; Pitta benefits from the cool start',
    sleepNote: 'Pitta-Kapha: strict 10 PM — neither dosha benefits from late nights',
    detoxNote: 'Pitta fire amplified by screens; Kapha inertia worsened by passive content'
  },
  'vata-kapha': {
    wake:  '05:30', sleep: '22:00', detox: '21:00',
    wakeNote:  'Vata needs consistency; Kapha needs early rising — 5:30 AM serves both',
    sleepNote: 'Vata benefits from slightly earlier sleep; 10 PM is the outer boundary',
    detoxNote: 'Vata anxiety and Kapha heaviness both worsen with evening screen time'
  },
  'kapha-pitta-vata': {
    wake:  '05:30', sleep: '22:00', detox: '21:00',
    wakeNote:  'Tridoshic: 5:30 AM serves all three doshas — observe seasonally',
    sleepNote: 'Tridoshic constitution: follow the season for fine-tuning',
    detoxNote: 'All doshas benefit from evening digital stillness — honour this practice'
  },
  /* Fallback */
  'default': {
    wake:  '06:00', sleep: '22:00', detox: '21:00',
    wakeNote:  'A consistent wake time is the foundation of all Ayurvedic practice',
    sleepNote: 'Sleeping before 10 PM protects Ojas — your vital essence',
    detoxNote: 'Reducing screen time after 9 PM measurably improves sleep quality'
  }
};

/* ─────────────────────────────────────────────────────────────
   MODULE 3 · TRADITION × ACTIVITY SPIRITUAL CONTENT LIBRARY
   Indexed: ACTIVITY_CONTENT[tradition][activityKey]
   Each entry has: verse, source, and a short note.
   Strict filtering — tradition keys never cross-pollinate.
   ───────────────────────────────────────────────────────────── */
var ACTIVITY_CONTENT = {

  hindu: {
    wake: {
      verse: 'कराग्रे वसते लक्ष्मीः करमध्ये सरस्वती। करमूले तु गोविन्दः प्रभाते करदर्शनम्॥',
      trans: 'Behold your hands at dawn. At the fingertips — Lakshmi. At the centre — Saraswati. At the root — Govinda.',
      source: 'Traditional · morning consecration'
    },
    meditation: {
      verse: 'ध्यायेन्नित्यं महेशं रजतगिरिनिभं चारुचन्द्रावतंसम्।',
      trans: 'Meditate always on the great Lord — pure as the silver mountain, luminous as the crescent moon.',
      source: 'Shiva Dhyana Shloka'
    },
    pranayama: {
      verse: 'यमाद्रक्षति तिक्ष्णानां द्रव्याणां हि प्रयोगतः।',
      trans: 'The breath is the bridge between the body and the mind. Regulate the breath and the mind follows.',
      source: 'Hatha Yoga Pradipika · on pranayama'
    },
    yoga: {
      verse: 'योगश्चित्तवृत्तिनिरोधः',
      trans: 'Yoga is the cessation of the movements of the mind. Still the fluctuations — and you are free.',
      source: 'Patanjali Yoga Sutras 1.2'
    },
    walk: {
      verse: 'उद्धरेदात्मनात्मानं नात्मानमवसादयेत्।',
      trans: 'Lift yourself by yourself. Do not let yourself fall. The self is the only true friend of the self.',
      source: 'Bhagavad Gita 6.5'
    },
    breakfast: {
      verse: 'ब्रह्मार्पणं ब्रह्म हविर्ब्रह्माग्नौ ब्रह्मणा हुतम्।',
      trans: 'This food is Brahman. The act of offering is Brahman. The fire of digestion is Brahman. All is Brahman.',
      source: 'Bhagavad Gita 4.24'
    },
    lunch: {
      verse: 'अहं वैश्वानरो भूत्वा प्राणिनां देहमाश्रितः।',
      trans: 'I am the digestive fire in all living beings. I accept this food as an offering into the sacred fire within.',
      source: 'Bhagavad Gita 15.14'
    },
    dinner: {
      verse: 'हितभुक् मितभुक् ऋतभुक्।',
      trans: 'Eat what is beneficial. Eat in moderation. Eat what is right for the season. These three are Ayurveda\'s complete dietary teaching.',
      source: 'Charaka Samhita · dietary principles'
    },
    work: {
      verse: 'कर्मण्येवाधिकारस्ते मा फलेषु कदाचन।',
      trans: 'You have the right to action — never to its fruits. Act fully. Release the result completely.',
      source: 'Bhagavad Gita 2.47'
    },
    reading: {
      verse: 'स्वाध्यायान्मा प्रमदः।',
      trans: 'Do not neglect self-study. Svadhyaya — reading, reflection, inquiry — is the fourth Niyama of Patanjali.',
      source: 'Taittiriya Upanishad · do not be negligent in self-study'
    },
    journaling: {
      verse: 'स्वाध्यायात् परमं तपः।',
      trans: 'Self-study is the highest austerity. Write to see yourself clearly — without judgment, without pretense.',
      source: 'Manusmriti · on Svadhyaya'
    },
    abhyanga: {
      verse: 'अभ्यङ्गमाचरेन्नित्यं स जराश्रमवातहा।',
      trans: 'Practice Abhyanga daily. It removes fatigue, counteracts ageing, and pacifies Vata. This is Ayurveda\'s greatest gift to the body.',
      source: 'Ashtanga Hridayam · on Abhyanga'
    },
    sleep: {
      verse: 'असतो मा सद्गमय। तमसो मा ज्योतिर्गमय। मृत्योर्माऽमृतं गमय। ॐ शान्तिः।',
      trans: 'Lead me from untruth to truth. From darkness to light. From the fear of death to the knowledge of immortality. Peace.',
      source: 'Brihadaranyaka Upanishad 1.3.28 · the sleep prayer'
    },
    detox: {
      verse: 'प्रत्याहारोऽस्य परमा ज्ञेया योगस्य साधना।',
      trans: 'Pratyahara — the withdrawal of the senses — is the highest method of yoga practice. Turn inward. The evening is for this.',
      source: 'Yoga teachings · on Pratyahara'
    },
    custom: {
      verse: 'योगस्थः कुरु कर्माणि सङ्गं त्यक्त्वा धनञ्जय।',
      trans: 'Be steadfast in yoga. Perform your action, abandoning attachment to results, in success and failure alike.',
      source: 'Bhagavad Gita 2.48'
    }
  },

  thay: {
    wake: {
      verse: 'Waking up this morning, I smile. Twenty-four brand new hours are before me. I vow to live fully in each moment, and to look at all beings with eyes of compassion.',
      source: 'Thich Nhat Hanh · Morning gatha · Plum Village'
    },
    meditation: {
      verse: 'Breathing in, I calm my body. Breathing out, I smile. Dwelling in the present moment, I know this is a wonderful moment.',
      source: 'Thich Nhat Hanh · The miracle of mindfulness'
    },
    pranayama: {
      verse: 'Our true home is in the present moment. When you breathe in and are aware of your in-breath, you touch the miracle of being alive.',
      source: 'Thich Nhat Hanh · Breathe, You Are Alive'
    },
    yoga: {
      verse: 'Breathing in, I am aware of my body. Breathing out, I release all tension in my body. I bring my body and mind together as one.',
      source: 'Thich Nhat Hanh · body awareness gatha'
    },
    walk: {
      verse: 'I have arrived. I am home. In the here and in the now. I am solid. I am free. In the ultimate I dwell.',
      source: 'Thich Nhat Hanh · walking meditation gatha'
    },
    breakfast: {
      verse: 'This food is a gift of the Earth, the sky, numerous living beings, and much hard work. May we eat in mindfulness and gratitude, so as to be worthy to receive it.',
      source: 'Plum Village · Five Contemplations before eating'
    },
    lunch: {
      verse: 'In this food I see clearly the presence of the entire universe supporting my existence. May I eat with awareness, gratitude, and compassion.',
      source: 'Plum Village · adapted Five Contemplations'
    },
    dinner: {
      verse: 'This meal is a circle of giving. The Earth, the rain, the farmer, the cook — all are present in this bowl. I receive them with gratitude.',
      source: 'Plum Village · evening meal gatha'
    },
    work: {
      verse: 'Turning on the computer, my mind gets in touch with the store. I vow to transform habit energies to help love and understanding grow.',
      source: 'Thich Nhat Hanh · Gathas for Daily Use, No. 47'
    },
    reading: {
      verse: 'Opening this book, I am aware that words are a raft to carry me, not the shore itself. May I read with a beginner\'s mind.',
      source: 'Plum Village · gatha for reading'
    },
    journaling: {
      verse: 'Taking up the pen, I vow to speak only truth — first to myself. May these words be a flower I offer to my own understanding.',
      source: 'Plum Village · gatha for writing'
    },
    abhyanga: {
      verse: 'Washing my hands, I am aware that I am touching the water of the Earth. This moment is a gift. I receive it with full attention.',
      source: 'Thich Nhat Hanh · gatha for washing'
    },
    sleep: {
      verse: 'Falling into the arms of the Earth, I let go of the day. The Earth holds me. The breath holds me. Nothing is lost. Everything is transformed.',
      source: 'Thich Nhat Hanh · sleep gatha · Plum Village'
    },
    detox: {
      verse: 'Turning off the phone, I step back from the river of information. In this stillness, I return to myself. This is my true home.',
      source: 'Plum Village · gatha for turning off devices'
    },
    custom: {
      verse: 'In this moment, I am engaged in what is before me. I bring the quality of my full presence. This is my practice.',
      source: 'Thich Nhat Hanh · on engaged mindfulness'
    }
  },

  buddhist: {
    wake: {
      verse: 'May I be happy. May I be well. May I be peaceful. May I be free from suffering.',
      source: 'Metta Sutta · loving-kindness for oneself at dawn'
    },
    meditation: {
      verse: 'Do not dwell in the past. Do not dream of the future. Concentrate the mind on the present moment. This is the complete teaching.',
      source: 'Dhammapada verse 1 · attributed to the Buddha'
    },
    pranayama: {
      verse: 'Anapanasati — mindfulness of breathing — when developed and cultivated, is of great fruit, of great benefit. It fulfills the four foundations of mindfulness.',
      source: 'Anapanasati Sutta · Majjhima Nikaya 118'
    },
    yoga: {
      verse: 'In walking, know that you are walking. In standing, know that you are standing. This awareness in all postures is the fourth foundation of mindfulness.',
      source: 'Satipatthana Sutta · on mindfulness of the body'
    },
    walk: {
      verse: 'When walking, the practitioner is aware "I am walking." When standing still, they are aware "I am standing." This is the practice of clear comprehension.',
      source: 'Satipatthana Sutta · Majjhima Nikaya 10'
    },
    breakfast: {
      verse: 'I eat this food not for pleasure, not for intoxication, not for the sake of physical beauty — but solely to sustain this body for practice.',
      source: 'Theravada teaching · right consumption'
    },
    lunch: {
      verse: 'Reflect wisely on this food: not for amusement, not for intoxication, not for the sake of physical beauty — but simply to endure.',
      source: 'Pali Canon · reflection on food'
    },
    dinner: {
      verse: 'Knowing the right measure in eating, one eats with attention. Thus all feelings become peaceful and the body is sustained in lightness.',
      source: 'Theravada teaching · mindful eating'
    },
    work: {
      verse: 'Right effort: prevent unwholesome states from arising. Abandon those that have arisen. Cultivate wholesome states. Sustain what is already good.',
      source: 'Noble Eightfold Path · Sammā vāyāma'
    },
    reading: {
      verse: 'There are four nutriments that sustain beings. The fourth is consciousness. Feed your consciousness only with what nourishes liberation.',
      source: 'Pali Canon · on the four nutriments'
    },
    journaling: {
      verse: 'Know what you think. Know what you feel. Know what you do. This triple knowing — of thought, emotion, action — is the beginning of wisdom.',
      source: 'Theravada teaching · on sati'
    },
    abhyanga: {
      verse: 'Care for the body as the vessel of practice. Without this body, there is no path. Tend it with the same mindfulness you bring to meditation.',
      source: 'Buddhist teaching · on care for the body'
    },
    sleep: {
      verse: 'May all beings be happy, may all beings be safe, may all beings be well, may all beings be free from suffering.',
      source: 'Metta Sutta · dedication of merit before sleep'
    },
    detox: {
      verse: 'The wise one restrains the senses, not running after sounds, sights, tastes. This restraint is the beginning of genuine peace.',
      source: 'Pali Canon · Indriya-samvara (sense restraint)'
    },
    custom: {
      verse: 'Whatever is done with mindfulness — however small — is karmically significant. Whatever is done without mindfulness — however grand — is merely movement.',
      source: 'Theravada teaching · on Sati in action'
    }
  },

  universal: {
    wake: {
      verse: 'Before this day begins — breathe once, fully. Notice that you are here. That you are alive. That the world exists. That is enough to begin.',
      source: 'Universal mindfulness practice'
    },
    meditation: {
      verse: 'Sitting quietly, doing nothing — spring comes and the grass grows by itself.',
      source: 'Zen proverb · on the power of stillness'
    },
    pranayama: {
      verse: 'The breath is always here. Before the worry was here, the breath was here. After the worry is gone, the breath will still be here.',
      source: 'Universal mindfulness teaching'
    },
    yoga: {
      verse: 'The body is the only thing you will inhabit your entire life. Every moment you spend inside it with awareness is a moment well spent.',
      source: 'Universal embodiment practice'
    },
    walk: {
      verse: 'Solvitur ambulando — it is solved by walking. Whatever you cannot solve sitting still, take it for a walk.',
      source: 'Latin proverb · attributed to Saint Augustine'
    },
    breakfast: {
      verse: 'Before eating — pause. Name one living thing that made this meal possible. Then eat with that awareness. This is complete gratitude practice.',
      source: 'Universal mindful eating practice'
    },
    lunch: {
      verse: 'Eat slowly. Put the fork down between bites. Chew completely. This is not advice — it is the difference between eating and nourishment.',
      source: 'Universal mindful eating · evidence-based practice'
    },
    dinner: {
      verse: 'End the day as you began it — with simplicity. A light dinner, eaten slowly, with someone you love or with your own quiet company.',
      source: 'Universal wellness practice'
    },
    work: {
      verse: 'The quality of your attention is the quality of your work. To be fully present — not multitasking, not half-elsewhere — is the rarest skill of the age.',
      source: 'Universal focus practice'
    },
    reading: {
      verse: 'Read not to contradict or confute, nor to believe and take for granted, but to weigh and consider.',
      source: 'Francis Bacon · Essays'
    },
    journaling: {
      verse: 'The unexamined life is not worth living. But the examined life that is written is worth re-examining — that is why you keep a journal.',
      source: 'After Socrates · on self-inquiry'
    },
    abhyanga: {
      verse: 'Taking care of your body is not vanity — it is the recognition that this body is the instrument through which you live your entire life.',
      source: 'Universal wellness practice'
    },
    sleep: {
      verse: 'Today is complete. What was done is done. What was left undone rests now. You may rest too. Tomorrow the page turns.',
      source: 'Universal evening reflection'
    },
    detox: {
      verse: 'Every hour without a screen is an hour you gave back to yourself. Time is the one currency you cannot earn more of. Spend it on what is real.',
      source: 'Universal digital wellness practice'
    },
    custom: {
      verse: 'Whatever you do — do it with your full attention. The quantity of life matters less than the quality of presence you bring to it.',
      source: 'Universal mindfulness principle'
    }
  }

};

/* ─────────────────────────────────────────────────────────────
   MODULE 4 · SCHEDULE STATE HELPERS
   STATE.schedule  = array of activity objects:
   {
     id:         string (uuid),
     type:       string (key in ACTIVITY_TYPES),
     customName: string (only when type === 'custom'),
     startTime:  string '07:00',
     endTime:    string '07:30',
     reminder:   boolean,
     notes:      string,
     done:       boolean   (today's completion flag)
   }

   STATE.smartPrefs = {
     wake:  '05:30',
     sleep: '22:00',
     detox: '21:00'
   }
   ───────────────────────────────────────────────────────────── */

/* Initialise schedule arrays if they don't exist */
function ensureScheduleState() {
  if (!STATE.schedule)    STATE.schedule    = [];
  if (!STATE.smartPrefs)  STATE.smartPrefs  = null; // null = use dosha defaults
}

/* Get the dosha-appropriate smart defaults */
function getSmartDefaults() {
  ensureScheduleState();
  if (STATE.smartPrefs) return STATE.smartPrefs;

  var combo = (STATE.doshaCombo || []).slice().sort().join('-');
  return SMART_DEFAULTS_BY_DOSHA[combo]
      || SMART_DEFAULTS_BY_DOSHA['default'];
}

/* UUID generator (simple, collision-safe for this use-case) */
function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/* Parse '07:30' → minutes from midnight */
function timeToMins(t) {
  var parts = (t || '00:00').split(':');
  return parseInt(parts[0]) * 60 + parseInt(parts[1]);
}

/* Minutes from midnight → '07:30' */
function minsToTime(m) {
  var h = Math.floor(m / 60) % 24;
  var mm = m % 60;
  return String(h).padStart(2,'0') + ':' + String(mm).padStart(2,'0');
}

/* Duration in minutes → human string */
function durationLabel(startTime, endTime) {
  var diff = timeToMins(endTime) - timeToMins(startTime);
  if (diff <= 0) diff += 1440; // overnight
  if (diff < 60)  return diff + ' min';
  var h = Math.floor(diff / 60), m = diff % 60;
  return h + 'h' + (m ? ' ' + m + 'min' : '');
}

/* Format '07:30' → '7:30 AM' */
function formatTime(t) {
  var parts = (t || '00:00').split(':');
  var h = parseInt(parts[0]), m = parts[1];
  var ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return h + ':' + m + ' ' + ampm;
}

/* Sort schedule by start time */
function sortedSchedule() {
  return (STATE.schedule || []).slice().sort(function(a, b) {
    return timeToMins(a.startTime) - timeToMins(b.startTime);
  });
}

/* Get spiritual content for an activity, tradition-filtered */
function getActivityContent(actType, tradition) {
  var trad = tradition || STATE.tradition || 'universal';
  var tradContent = ACTIVITY_CONTENT[trad] || ACTIVITY_CONTENT.universal;
  return tradContent[actType] || tradContent.custom;
}

/* Get display info for an activity type */
function getTypeInfo(type) {
  return ACTIVITY_TYPES[type] || ACTIVITY_TYPES.custom;
}

/* Is an activity "active" right now (current time within its window)? */
function isActivityNow(slot) {
  var now  = new Date();
  var cur  = now.getHours() * 60 + now.getMinutes();
  var s    = timeToMins(slot.startTime);
  var e    = timeToMins(slot.endTime);
  if (e <= s) e += 1440;          // overnight
  return cur >= s && cur < e;
}

/* Is an activity in the past today? */
function isActivityPast(slot) {
  var now = new Date();
  var cur = now.getHours() * 60 + now.getMinutes();
  return timeToMins(slot.endTime) <= cur;
}

/* ─────────────────────────────────────────────────────────────
   MODULE 5 · TAB SWITCHER
   ───────────────────────────────────────────────────────────── */
function switchDinaTab(tab) {
  var suggested = document.getElementById('dina-panel-suggested');
  var schedule  = document.getElementById('dina-panel-schedule');
  var tabSug    = document.getElementById('tab-suggested');
  var tabSch    = document.getElementById('tab-schedule');

  if (tab === 'suggested') {
    if (suggested) suggested.style.display = '';
    if (schedule)  schedule.style.display  = 'none';
    if (tabSug)    { tabSug.classList.add('active'); }
    if (tabSch)    { tabSch.classList.remove('active'); }
    renderDinacharya();
  } else {
    if (suggested) suggested.style.display = 'none';
    if (schedule)  schedule.style.display  = '';
    if (tabSug)    { tabSug.classList.remove('active'); }
    if (tabSch)    { tabSch.classList.add('active'); }
    renderSmartDefaults();
    renderSchedule();
  }
}

/* ─────────────────────────────────────────────────────────────
   MODULE 6 · SMART DEFAULTS STRIP
   Shows editable wake / sleep / detox chips in Suggested panel
   ───────────────────────────────────────────────────────────── */
function renderSmartDefaults() {
  var container = document.getElementById('smartDefaults');
  if (!container) return;

  var d = getSmartDefaults();

  container.innerHTML = [
    '<div class="sd-row">',
      '<div class="sd-label">Smart defaults <span class="sd-sublabel">— tap to adjust</span></div>',
    '</div>',
    '<div class="sd-chips">',
      buildSDChip('🌅', 'Wake up', d.wake, 'wake', d.wakeNote),
      buildSDChip('🌙', 'Sleep',   d.sleep,'sleep',d.sleepNote),
      buildSDChip('📵', 'Detox',   d.detox,'detox',d.detoxNote),
    '</div>'
  ].join('');
}

function buildSDChip(icon, label, time, key, note) {
  return [
    '<div class="sd-chip" onclick="editSmartDefault(\'' + key + '\',\'' + time + '\',\'' + escSDQuotes(note) + '\')">',
      '<span class="sd-chip-icon">' + icon + '</span>',
      '<div class="sd-chip-body">',
        '<div class="sd-chip-label">' + label + '</div>',
        '<div class="sd-chip-time">' + formatTime(time) + '</div>',
      '</div>',
      '<span class="sd-chip-edit">✎</span>',
    '</div>'
  ].join('');
}

function escSDQuotes(s) {
  return (s || '').replace(/'/g, '\\\'');
}

/* Inline editor for a smart default — repurposes the modal sheet */
function editSmartDefault(key, currentTime, note) {
  var labels = { wake:'Wake-up time', sleep:'Sleep time', detox:'Digital detox start' };

  document.getElementById('modalTitle').textContent     = labels[key] || key;
  document.getElementById('actTypeGrid').innerHTML      = '';
  document.getElementById('customNameWrap').style.display = 'none';
  document.getElementById('actNotes').value             = '';
  document.getElementById('actNotes').placeholder       = note;
  document.getElementById('actStartTime').value         = currentTime;
  document.getElementById('actEndTime').value           = currentTime;
  document.getElementById('modalPreview').innerHTML     =
    '<div style="font-style:italic;color:var(--mu)">' + note + '</div>';
  document.getElementById('modalDeleteBtn').style.display = 'none';

  // Override save to update smart default
  document.querySelector('.modal-save-btn').onclick = function() {
    var t = document.getElementById('actStartTime').value;
    var prefs = getSmartDefaults();
    var newPrefs = Object.assign({}, prefs);
    newPrefs[key] = t;
    STATE.smartPrefs = newPrefs;
    saveState();
    closeModal();
    renderSmartDefaults();
    renderDinacharya(); // regenerate timeline with new default
  };

  // Show time row only
  document.querySelector('.time-row').style.display = 'flex';
  document.getElementById('reminderToggle').closest('.modal-reminder-row').style.display = 'none';
  document.getElementById('actTypeGrid').closest('div.modal-section-label') &&
    (document.getElementById('actTypeGrid').closest('div.modal-section-label').style.display = 'none');

  openModal(null, true); // second arg = smartDefault mode
}

/* ─────────────────────────────────────────────────────────────
   MODULE 7 · SCHEDULE RENDERER
   Renders: summary stats + 24h visual bar + sorted card list
   ───────────────────────────────────────────────────────────── */
function renderSchedule() {
  ensureScheduleState();
  renderScheduleSummary();
  renderDayVisual();
  renderScheduleList();
  updateScheduleCount();
}

/* Summary stat chips */
function renderScheduleSummary() {
  var el = document.getElementById('schedSummary');
  if (!el) return;

  var slots  = STATE.schedule || [];
  var total  = slots.length;
  var done   = slots.filter(function(s){ return s.done; }).length;
  var reminders = slots.filter(function(s){ return s.reminder; }).length;
  var hours  = slots.reduce(function(acc, s) {
    var diff = timeToMins(s.endTime) - timeToMins(s.startTime);
    if (diff < 0) diff += 1440;
    return acc + diff;
  }, 0);
  var hoursStr = Math.floor(hours / 60) + 'h ' + (hours % 60 ? hours % 60 + 'm' : '');

  el.innerHTML = [
    '<div class="sched-stat"><div class="sched-stat-num">' + total + '</div><div class="sched-stat-label">Activities</div></div>',
    '<div class="sched-stat"><div class="sched-stat-num">' + done  + '</div><div class="sched-stat-label">Done today</div></div>',
    '<div class="sched-stat"><div class="sched-stat-num">' + reminders + '</div><div class="sched-stat-label">Reminders</div></div>',
    '<div class="sched-stat" style="background:var(--sfp);border-color:rgba(232,101,26,.2)"><div class="sched-stat-num" style="color:var(--sf)">' + (total ? hoursStr : '—') + '</div><div class="sched-stat-label">Scheduled</div></div>'
  ].join('');
}

/* 24-hour visual bar — each activity is a proportional block */
function renderDayVisual() {
  var el = document.getElementById('dayVisual');
  if (!el) return;

  var slots = sortedSchedule();
  if (slots.length === 0) {
    el.innerHTML = '<div style="width:100%;height:100%;background:rgba(180,100,40,.06);display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--mu);letter-spacing:.08em">No activities scheduled</div>';
    return;
  }

  var blocks = slots.map(function(slot) {
    var info   = getTypeInfo(slot.type);
    var sMin   = timeToMins(slot.startTime);
    var eMin   = timeToMins(slot.endTime);
    if (eMin <= sMin) eMin += 1440;
    var left   = (sMin / 1440 * 100).toFixed(2) + '%';
    var width  = Math.max(((eMin - sMin) / 1440 * 100), 0.8).toFixed(2) + '%';
    var isNow  = isActivityNow(slot);
    var label  = slot.type === 'custom' ? (slot.customName || 'Custom') : info.label;
    return '<div class="day-block" title="' + label + ' ' + formatTime(slot.startTime) + '"'
      + ' style="left:' + left + ';width:' + width + ';background:' + info.colour + ';opacity:' + (slot.done ? '.4' : isNow ? '1' : '.8') + '"'
      + (isNow ? ' data-now="true"' : '') + '></div>';
  }).join('');

  // Current time indicator
  var now  = new Date();
  var cur  = (now.getHours() * 60 + now.getMinutes()) / 1440 * 100;
  var line = '<div class="day-now-line" style="left:' + cur.toFixed(2) + '%"></div>';

  el.innerHTML = blocks + line;
}

/* Schedule card list */
function renderScheduleList() {
  var el = document.getElementById('schedList');
  if (!el) return;

  var slots = sortedSchedule();

  if (slots.length === 0) {
    el.innerHTML = [
      '<div class="sched-empty">',
        '<span class="sched-empty-icon">🌿</span>',
        'Your day is an empty canvas.<br>',
        'Add your first activity to begin<br>personalising your dinacharya.',
      '</div>'
    ].join('');
    return;
  }

  el.innerHTML = slots.map(function(slot) {
    return buildScheduleCard(slot);
  }).join('');
}

function buildScheduleCard(slot) {
  var info     = getTypeInfo(slot.type);
  var isNow    = isActivityNow(slot);
  var isPast   = isActivityPast(slot);
  var label    = slot.type === 'custom' ? (slot.customName || 'Custom') : info.label;
  var dur      = durationLabel(slot.startTime, slot.endTime);
  var content  = getActivityContent(slot.type, STATE.tradition);
  var cardCls  = isNow ? 'card-active' : isPast ? 'card-done-c' : '';
  var remBadge = slot.reminder
    ? '<span class="sched-reminder-badge">🔔 Reminder on</span>'
    : '';
  var doneMark = isPast || slot.done
    ? '<button class="sched-done-btn' + (slot.done ? ' done' : '') + '" onclick="toggleDone(\'' + slot.id + '\',event)">' + (slot.done ? '✓' : '○') + '</button>'
    : '<button class="sched-done-btn" onclick="toggleDone(\'' + slot.id + '\',event)">○</button>';

  return [
    '<div class="sched-card ' + cardCls + '" onclick="openModal(\'' + slot.id + '\')">',
      '<div class="sched-card-stripe" style="background:' + info.colour + '"></div>',
      '<div class="sched-card-body">',
        '<div class="sched-icon-wrap" style="background:' + info.bg + '">',
          '<span>' + info.icon + '</span>',
        '</div>',
        '<div class="sched-info">',
          '<div class="sched-name">' + label + (isNow ? ' <span style="font-size:9px;color:var(--sf);font-weight:600;margin-left:4px">● NOW</span>' : '') + '</div>',
          '<div class="sched-time-row">',
            '<span class="sched-time">' + formatTime(slot.startTime) + '</span>',
            '<span class="sched-duration">→ ' + formatTime(slot.endTime) + ' (' + dur + ')</span>',
            remBadge,
          '</div>',
          slot.notes ? '<div class="sched-notes">' + slot.notes + '</div>' : '',
          '<div class="sched-shloka">',
            '<span class="sched-shloka-text">"' + (content.verse || '') + '"</span>',
          '</div>',
        '</div>',
        doneMark,
      '</div>',
    '</div>'
  ].join('');
}

/* Toggle completion mark */
function toggleDone(id, evt) {
  evt && evt.stopPropagation();
  var slot = STATE.schedule.find(function(s){ return s.id === id; });
  if (!slot) return;
  slot.done = !slot.done;
  if (slot.done) recordActivity();
  saveState();
  renderSchedule();
}

/* Update the count badge on the My Schedule tab */
function updateScheduleCount() {
  var el = document.getElementById('scheduleCount');
  if (el) el.textContent = (STATE.schedule || []).length;
}

/* ─────────────────────────────────────────────────────────────
   MODULE 8 · ACTIVITY MODAL (Add / Edit / Delete)
   ───────────────────────────────────────────────────────────── */
var _editingId  = null;   // null = adding new; string = editing existing
var _selType    = null;   // currently selected activity type

function renderActivityTypeGrid() {
  var grid = document.getElementById('actTypeGrid');
  if (!grid) return;

  var combo   = (STATE.doshaCombo || []).slice().sort().join('-');
  var isMulti = combo.indexOf('-') !== -1;

  grid.innerHTML = Object.keys(ACTIVITY_TYPES).map(function(key) {
    var t       = ACTIVITY_TYPES[key];
    var isSel   = key === _selType;
    // Highlight dosha-relevant types with a subtle indicator
    var relevant = t.doshaRelevant.some(function(d){ return (STATE.doshaCombo||[]).indexOf(d) !== -1; });
    return [
      '<div class="act-type-card' + (isSel ? ' selected' : '') + '"',
      ' onclick="selectActivityType(\'' + key + '\')" title="' + t.label + '">',
        relevant ? '<span class="act-relevance-dot"></span>' : '',
        '<span class="act-type-icon">' + t.icon + '</span>',
        '<div class="act-type-name">' + t.label + '</div>',
      '</div>'
    ].join('');
  }).join('');
}

function selectActivityType(key) {
  _selType = key;

  // Highlight selected card
  document.querySelectorAll('.act-type-card').forEach(function(c){ c.classList.remove('selected'); });
  var target = document.querySelector('[onclick="selectActivityType(\'' + key + '\')"]');
  if (target) target.classList.add('selected');

  // Show / hide custom name field
  var customWrap = document.getElementById('customNameWrap');
  if (customWrap) customWrap.style.display = (key === 'custom') ? 'block' : 'none';

  // Set default duration
  var info = getTypeInfo(key);
  var startVal = document.getElementById('actStartTime').value || '07:00';
  var startMins = timeToMins(startVal);
  var endMins   = startMins + info.defaultDuration;
  document.getElementById('actEndTime').value = minsToTime(endMins);

  // Update spiritual preview
  updateModalPreview(key);
}

function updateModalPreview(key) {
  var preview = document.getElementById('modalPreview');
  if (!preview) return;
  var content = getActivityContent(key, STATE.tradition);
  var trad    = TRADITION_CONTENT[STATE.tradition] || TRADITION_CONTENT.universal;
  var info    = getTypeInfo(key);

  preview.innerHTML = [
    '<div style="display:flex;align-items:center;gap:7px;margin-bottom:8px">',
      '<span style="font-size:16px">' + info.icon + '</span>',
      '<span style="font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--jade)">' + (trad.tradLabel || '') + '</span>',
    '</div>',
    '<div style="font-family:var(--fr);font-size:13px;font-style:italic;color:var(--td);line-height:1.65;margin-bottom:6px">',
      '"' + (content.verse || '') + '"',
    '</div>',
    content.trans ? '<div style="font-size:11px;color:var(--tm);line-height:1.55;margin-bottom:4px">' + content.trans + '</div>' : '',
    '<div style="font-size:9px;color:var(--mu);letter-spacing:.06em">' + (content.source || '') + '</div>'
  ].join('');
}

/* Open modal: id=null → add; id=string → edit */
function openModal(id, smartDefaultMode) {
  _editingId = id;
  _selType   = null;

  // Reset modal to default state
  var modal = document.getElementById('activityModal');
  var sheet = document.getElementById('modalSheet');
  var delBtn = document.getElementById('modalDeleteBtn');

  // Restore default behaviour for save button
  document.querySelector('.modal-save-btn').onclick = saveActivity;

  // Restore hidden elements
  var reminderRow = document.querySelector('.modal-reminder-row');
  if (reminderRow) reminderRow.style.display = 'flex';

  // Restore modal section labels
  document.querySelectorAll('.modal-section-label').forEach(function(el){
    el.style.display = '';
  });
  document.querySelector('.time-row').style.display = 'flex';

  if (smartDefaultMode) {
    // Already configured by editSmartDefault()
    if (modal) modal.classList.add('open');
    return;
  }

  if (id) {
    // EDIT MODE
    var slot = STATE.schedule.find(function(s){ return s.id === id; });
    if (!slot) return;
    _selType = slot.type;
    document.getElementById('modalTitle').textContent   = 'Edit activity';
    document.getElementById('actStartTime').value       = slot.startTime;
    document.getElementById('actEndTime').value         = slot.endTime;
    document.getElementById('actNotes').value           = slot.notes || '';
    document.getElementById('actNotes').placeholder     = 'What do you intend to bring to this time?';
    document.getElementById('reminderToggle').className = 'toggle' + (slot.reminder ? ' on' : '');
    if (delBtn) delBtn.style.display = 'block';

    var customWrap = document.getElementById('customNameWrap');
    if (customWrap) {
      customWrap.style.display = (slot.type === 'custom') ? 'block' : 'none';
      document.getElementById('customNameInput').value = slot.customName || '';
    }
  } else {
    // ADD MODE
    document.getElementById('modalTitle').textContent   = 'Add activity';
    document.getElementById('actStartTime').value       = nextSuggestedTime();
    document.getElementById('actEndTime').value         = minsToTime(timeToMins(nextSuggestedTime()) + 30);
    document.getElementById('actNotes').value           = '';
    document.getElementById('actNotes').placeholder     = 'What do you intend to bring to this time?';
    document.getElementById('reminderToggle').className = 'toggle on';
    if (delBtn) delBtn.style.display = 'none';
    var customWrap = document.getElementById('customNameWrap');
    if (customWrap) customWrap.style.display = 'none';

    document.getElementById('modalPreview').innerHTML =
      '<div style="color:var(--mu);font-size:12px;font-style:italic">Choose an activity type above to see the teaching</div>';
  }

  renderActivityTypeGrid();
  if (id) updateModalPreview(_selType);

  if (modal) modal.classList.add('open');
}

/* Suggest the next logical start time */
function nextSuggestedTime() {
  var slots = sortedSchedule();
  if (slots.length === 0) return '07:00';
  var last  = slots[slots.length - 1];
  var end   = timeToMins(last.endTime);
  return minsToTime(end + 15);
}

function closeModal() {
  var modal = document.getElementById('activityModal');
  if (modal) modal.classList.remove('open');
}

function closeModalBackdrop(evt) {
  if (evt.target === document.getElementById('activityModal')) closeModal();
}

/* Save (add or update) */
function saveActivity() {
  ensureScheduleState();
  if (!_selType && !_editingId) { alert('Please choose an activity type.'); return; }

  var type      = _selType;
  var startTime = document.getElementById('actStartTime').value;
  var endTime   = document.getElementById('actEndTime').value;
  var reminder  = document.getElementById('reminderToggle').classList.contains('on');
  var notes     = (document.getElementById('actNotes').value || '').trim();
  var custom    = (document.getElementById('customNameInput').value || '').trim();

  // Validation
  if (!startTime || !endTime) { alert('Please set a start and end time.'); return; }

  if (_editingId) {
    // Update existing
    var slot = STATE.schedule.find(function(s){ return s.id === _editingId; });
    if (slot) {
      if (type) slot.type = type;
      slot.startTime  = startTime;
      slot.endTime    = endTime;
      slot.reminder   = reminder;
      slot.notes      = notes;
      slot.customName = custom;
    }
  } else {
    // Create new
    STATE.schedule.push({
      id:         makeId(),
      type:       type || 'custom',
      customName: custom,
      startTime:  startTime,
      endTime:    endTime,
      reminder:   reminder,
      notes:      notes,
      done:       false
    });
  }

  saveState();
  scheduleAllReminders();
  closeModal();
  renderSchedule();
  recordActivity();
}

/* Delete */
function deleteActivity() {
  if (!_editingId) return;
  STATE.schedule = STATE.schedule.filter(function(s){ return s.id !== _editingId; });
  saveState();
  cancelAllReminders();
  scheduleAllReminders();
  closeModal();
  renderSchedule();
}

/* ─────────────────────────────────────────────────────────────
   MODULE 9 · REMINDER ENGINE
   Browser Notification API (requires permission) +
   in-app toast fallback (always works) +
   setInterval polling every 30 seconds
   ───────────────────────────────────────────────────────────── */
var _reminderIntervalId = null;

function requestNotificationPermission() {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
}

function scheduleAllReminders() {
  cancelAllReminders();
  _reminderIntervalId = setInterval(checkReminders, 30000); // poll every 30s
}

function cancelAllReminders() {
  if (_reminderIntervalId) clearInterval(_reminderIntervalId);
  _reminderIntervalId = null;
}

/* Check every 30 seconds whether any activity starts in the next minute */
function checkReminders() {
  var now    = new Date();
  var curMin = now.getHours() * 60 + now.getMinutes();
  var curSec = now.getSeconds();

  (STATE.schedule || []).forEach(function(slot) {
    if (!slot.reminder) return;
    var slotMin = timeToMins(slot.startTime);
    // Fire reminder when we are within 0–1 minutes of start
    if (slotMin === curMin) {
      fireReminder(slot);
    }
  });
}

function fireReminder(slot) {
  var info    = getTypeInfo(slot.type);
  var label   = slot.type === 'custom' ? (slot.customName || 'Custom') : info.label;
  var content = getActivityContent(slot.type, STATE.tradition);
  var verse   = content.verse || '';
  var source  = content.source || '';

  // Play bell sound
  if (STATE.soundUnlocked) {
    synthesiseBell();
    setTimeout(function(){ synthesiseOm(2.5); }, 2200);
  }

  // In-app toast (always)
  showReminderToast(info.icon, label, formatTime(slot.startTime), '"' + verse + '" — ' + source);

  // Browser notification (if permitted)
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification('Ārogya · ' + label, {
        body: '"' + verse.substring(0, 100) + (verse.length > 100 ? '…' : '') + '"',
        icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="%231A0A04"/><text y="48" x="32" font-size="42" text-anchor="middle" font-family="serif">ॐ</text></svg>',
        tag:  'arogya-' + slot.id,
        silent: false
      });
    } catch(e) {}
  }
}

function showReminderToast(icon, activity, time, teaching) {
  document.getElementById('toastIcon').textContent     = icon;
  document.getElementById('toastActivity').textContent = activity;
  document.getElementById('toastTime').textContent     = time;
  document.getElementById('toastTeaching').textContent = teaching;

  var toast = document.getElementById('reminderToast');
  if (toast) {
    toast.classList.add('show');
    // Auto-dismiss after 12 seconds
    setTimeout(function(){ toast.classList.remove('show'); }, 12000);
  }
}

function dismissToast() {
  var toast = document.getElementById('reminderToast');
  if (toast) toast.classList.remove('show');
}

/* ─────────────────────────────────────────────────────────────
   MODULE 10 · DOSHA-PERSONALIZED SUGGESTIONS
   When the My Schedule panel is first opened with an empty
   schedule, propose sensible activities based on dosha combo.
   ───────────────────────────────────────────────────────────── */
var DOSHA_SUGGESTIONS = {
  vata:  ['wake','pranayama','abhyanga','breakfast','meditation','work','lunch','walk','dinner','journaling','sleep'],
  pitta: ['wake','meditation','yoga','breakfast','work','lunch','work','dinner','journaling','detox','sleep'],
  kapha: ['wake','yoga','walk','pranayama','breakfast','work','lunch','walk','dinner','meditation','sleep']
};

function getSuggestedSchedule() {
  var combo   = (STATE.doshaCombo || ['pitta'])[0];
  var keys    = DOSHA_SUGGESTIONS[combo] || DOSHA_SUGGESTIONS.pitta;
  var d       = getSmartDefaults();
  var cursor  = timeToMins(d.wake);

  return keys.map(function(key) {
    var info = getTypeInfo(key);
    var dur  = info.defaultDuration;
    var slot = {
      id:         makeId(),
      type:       key,
      customName: '',
      startTime:  minsToTime(cursor),
      endTime:    minsToTime(cursor + dur),
      reminder:   true,
      notes:      '',
      done:       false
    };
    cursor += dur + 15;  // 15-min gap between activities
    return slot;
  });
}

/* Populate schedule from dosha suggestions */
function applySuggestedSchedule() {
  if ((STATE.schedule || []).length > 0) {
    if (!confirm('This will replace your current schedule with a dosha-personalised template. Continue?')) return;
  }
  STATE.schedule = getSuggestedSchedule();
  saveState();
  scheduleAllReminders();
  renderSchedule();
  recordActivity();
}

/* ─────────────────────────────────────────────────────────────
   MODULE 11 · INIT HOOK
   Called from the main init() after STATE is loaded.
   ───────────────────────────────────────────────────────────── */
function initScheduleModule() {
  ensureScheduleState();
  scheduleAllReminders();
  requestNotificationPermission();
  // Render smart defaults in suggested panel if user is onboarded
  if (STATE.onboardDone) renderSmartDefaults();
}

/* Export for use from main go() */
if (typeof window !== 'undefined') {
  window.switchDinaTab      = switchDinaTab;
  window.openModal          = openModal;
  window.closeModal         = closeModal;
  window.closeModalBackdrop = closeModalBackdrop;
  window.saveActivity       = saveActivity;
  window.deleteActivity     = deleteActivity;
  window.selectActivityType = selectActivityType;
  window.toggleDone         = toggleDone;
  window.dismissToast       = dismissToast;
  window.applySuggestedSchedule = applySuggestedSchedule;
  window.editSmartDefault   = editSmartDefault;
  window.initScheduleModule = initScheduleModule;
}
function handleBellTap() {
  console.log("Bell clicked 🔔");

  // Simple test sound
  let audio = document.getElementById("audio-om");

  if (audio) {
    audio.currentTime = 0;
    audio.play();
  } else {
    alert("Sound element not found");
  }
}
document.addEventListener("DOMContentLoaded", function() {
  renderDinacharya();
});